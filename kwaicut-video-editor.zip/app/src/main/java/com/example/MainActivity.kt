package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.example.ui.CameraScreen
import com.example.ui.EditorScreen
import com.example.ui.ExportScreen
import com.example.ui.HomeScreen
import com.example.ui.TemplatesScreen
import com.example.ui.theme.KwaiCutTheme
import com.example.viewmodel.EditorViewModel

enum class KwaiScreen {
    HOME,
    EDITOR,
    EXPORT,
    TEMPLATES,
    CAMERA
}

class MainActivity : ComponentActivity() {
    private val editorViewModel: EditorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            var currentScreen by remember { mutableStateOf(KwaiScreen.HOME) }

            KwaiCutTheme {
                Surface(
                    modifier = Modifier.fillMaxSize()
                ) {
                    when (currentScreen) {
                        KwaiScreen.HOME -> {
                            HomeScreen(
                                viewModel = editorViewModel,
                                onOpenEditor = { currentScreen = KwaiScreen.EDITOR },
                                onOpenTemplates = { currentScreen = KwaiScreen.TEMPLATES },
                                onOpenCamera = { currentScreen = KwaiScreen.CAMERA }
                            )
                        }
                        KwaiScreen.EDITOR -> {
                            EditorScreen(
                                viewModel = editorViewModel,
                                onBack = { currentScreen = KwaiScreen.HOME },
                                onOpenExport = { currentScreen = KwaiScreen.EXPORT }
                            )
                        }
                        KwaiScreen.EXPORT -> {
                            ExportScreen(
                                viewModel = editorViewModel,
                                onBack = { currentScreen = KwaiScreen.EDITOR },
                                onDoneToHome = { currentScreen = KwaiScreen.HOME }
                            )
                        }
                        KwaiScreen.TEMPLATES -> {
                            TemplatesScreen(
                                viewModel = editorViewModel,
                                onBack = { currentScreen = KwaiScreen.HOME },
                                onOpenEditor = { currentScreen = KwaiScreen.EDITOR }
                            )
                        }
                        KwaiScreen.CAMERA -> {
                            CameraScreen(
                                viewModel = editorViewModel,
                                onBack = { currentScreen = KwaiScreen.HOME },
                                onOpenEditor = { currentScreen = KwaiScreen.EDITOR }
                            )
                        }
                    }
                }
            }
        }
    }
}
