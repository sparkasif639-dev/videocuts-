package com.example.ui

import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ExportFps
import com.example.data.ExportQuality
import com.example.data.ExportResolution
import com.example.ui.theme.*
import com.example.video.CanvasVideoPlayer
import com.example.viewmodel.EditorViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExportScreen(
    viewModel: EditorViewModel,
    onBack: () -> Unit,
    onDoneToHome: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isExporting = viewModel.isExporting
    val progress = viewModel.exportProgress
    val animatedProgress by animateFloatAsState(targetValue = progress, label = "Export Progress")
    val successPath = viewModel.exportedSuccessPath
    var showConfigDialog by remember { mutableStateOf(false) }

    if (showConfigDialog) {
        ExportConfigurationDialog(
            viewModel = viewModel,
            onDismiss = { showConfigDialog = false },
            onConfirmExport = {
                showConfigDialog = false
                viewModel.startExport {}
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (successPath != null) "Export Ready!" else "High-Quality Export",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("export_back_button")) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = KwaiObsidianBg)
            )
        },
        containerColor = KwaiObsidianBg,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Preview Viewport
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(KwaiPanelSurface),
                contentAlignment = Alignment.Center
            ) {
                CanvasVideoPlayer(
                    playerState = viewModel.playerState,
                    showControls = false,
                    modifier = Modifier.fillMaxSize()
                )

                if (isExporting) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.82f))
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            if (viewModel.exportResolution == ExportResolution.RES_4K) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = KwaiGold,
                                    modifier = Modifier.testTag("4k_rendering_badge")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.HighQuality,
                                            contentDescription = null,
                                            tint = Color.Black,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Text(
                                            text = "4K ULTRA HD RENDERING",
                                            color = Color.Black,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                    }
                                }
                            }

                            Box(contentAlignment = Alignment.Center) {
                                CircularProgressIndicator(
                                    progress = { animatedProgress },
                                    color = KwaiMagenta,
                                    trackColor = KwaiCardSurface,
                                    strokeWidth = 6.dp,
                                    modifier = Modifier.size(68.dp)
                                )
                                Text(
                                    text = "${(animatedProgress * 100).toInt()}%",
                                    color = Color.White,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 15.sp
                                )
                            }

                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = viewModel.renderingStageText,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    modifier = Modifier.testTag("rendering_stage_text")
                                )

                                Text(
                                    text = "Step ${viewModel.renderingStageIndex} of ${viewModel.totalRenderingStages} • Est. ${viewModel.estimatedTimeRemainingSec}s remaining",
                                    color = KwaiCyan,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }

                            LinearProgressIndicator(
                                progress = { animatedProgress },
                                color = KwaiMagenta,
                                trackColor = KwaiCardSurface,
                                modifier = Modifier
                                    .fillMaxWidth(0.85f)
                                    .height(4.dp)
                                    .clip(RoundedCornerShape(2.dp))
                            )

                            Text(
                                text = "${viewModel.exportResolution.label} (${viewModel.exportResolution.width}x${viewModel.exportResolution.height}) • ${viewModel.exportFps.fps} FPS",
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }

            if (successPath != null) {
                // Success Export View & Social Sharing Hub
                ExportSuccessView(
                    resolution = viewModel.exportResolution.label,
                    fps = viewModel.exportFps.fps,
                    savedPath = successPath,
                    onShareToApp = { platform ->
                        if (platform == "Save Gallery" || platform == "Save Video to Gallery") {
                            Toast.makeText(context, "Video saved to Gallery!\nPath: $successPath", Toast.LENGTH_LONG).show()
                        } else {
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "video/*"
                                putExtra(Intent.EXTRA_SUBJECT, viewModel.projectTitle)
                                putExtra(Intent.EXTRA_TEXT, "Check out my video created with KwaiCut Video Editor! 🚀 #KwaiCut #Viral")
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "Share via $platform"))
                        }
                    },
                    onHomeClick = onDoneToHome
                )
            } else {
                // Export Configurations
                ExportConfigPanel(viewModel = viewModel)

                Spacer(modifier = Modifier.weight(1f))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Export Video to Gallery Button
                    Button(
                        onClick = { showConfigDialog = true },
                        enabled = !isExporting,
                        colors = ButtonDefaults.buttonColors(containerColor = KwaiGold),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(54.dp)
                            .testTag("export_to_gallery_direct_button")
                    ) {
                        Icon(imageVector = Icons.Default.Download, contentDescription = null, tint = Color.Black)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Save to Gallery",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = Color.Black
                        )
                    }

                    // Advanced HD Export Button
                    Button(
                        onClick = { showConfigDialog = true },
                        enabled = !isExporting,
                        colors = ButtonDefaults.buttonColors(containerColor = KwaiMagenta),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .weight(1.1f)
                            .height(54.dp)
                            .testTag("start_export_process_button")
                    ) {
                        Icon(imageVector = Icons.Default.RocketLaunch, contentDescription = null, tint = OnKwaiMagenta)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isExporting) "Exporting..." else "Start HD Export",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = OnKwaiMagenta
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ExportConfigPanel(viewModel: EditorViewModel) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = KwaiPanelSurface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Resolution
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Resolution", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ExportResolution.entries.forEach { res ->
                        FilterChip(
                            selected = viewModel.exportResolution == res,
                            onClick = { viewModel.exportResolution = res },
                            label = { Text(res.label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = KwaiMagenta,
                                selectedLabelColor = Color.White,
                                containerColor = KwaiCardSurface,
                                labelColor = TextSecondary
                            )
                        )
                    }
                }
            }

            // 2. Frame Rate
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Frame Rate", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ExportFps.entries.forEach { fps ->
                        FilterChip(
                            selected = viewModel.exportFps == fps,
                            onClick = { viewModel.exportFps = fps },
                            label = { Text("${fps.fps} FPS") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = KwaiCyan,
                                selectedLabelColor = Color.Black,
                                containerColor = KwaiCardSurface,
                                labelColor = TextSecondary
                            )
                        )
                    }
                }
            }

            // 3. Bitrate / Quality
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Bitrate & Quality", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ExportQuality.entries.forEach { quality ->
                        FilterChip(
                            selected = viewModel.exportQuality == quality,
                            onClick = { viewModel.exportQuality = quality },
                            label = { Text(quality.label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = KwaiGold,
                                selectedLabelColor = Color.Black,
                                containerColor = KwaiCardSurface,
                                labelColor = TextSecondary
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ExportSuccessView(
    resolution: String,
    fps: Int,
    savedPath: String? = null,
    onShareToApp: (String) -> Unit,
    onHomeClick: () -> Unit
) {
    val socialPlatforms = listOf(
        SocialTarget("TikTok", "🎵", KwaiMagenta),
        SocialTarget("Instagram Reels", "📸", KwaiCyan),
        SocialTarget("YouTube Shorts", "▶️", Color.Red),
        SocialTarget("WhatsApp Status", "💬", Color(0xFF25D366)),
        SocialTarget("Facebook", "👍", Color(0xFF1877F2)),
        SocialTarget("Save Gallery", "💾", KwaiGold)
    )

    Column(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxWidth()
    ) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = KwaiCyan.copy(alpha = 0.15f),
            border = androidx.compose.foundation.BorderStroke(1.dp, KwaiCyan)
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = KwaiCyan,
                    modifier = Modifier.size(32.dp)
                )
                Column {
                    Text("Export Saved to Gallery", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("Ultra Crisp $resolution • $fps FPS • Hardware Encoded", color = TextSecondary, fontSize = 12.sp)
                    if (savedPath != null) {
                        Text(savedPath, color = KwaiCyan, fontSize = 10.sp, maxLines = 1)
                    }
                }
            }
        }

        // Save Video to Phone Gallery Direct Button
        Button(
            onClick = { onShareToApp("Save Video to Gallery") },
            colors = ButtonDefaults.buttonColors(containerColor = KwaiGold),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("save_to_gallery_success_button")
        ) {
            Icon(imageVector = Icons.Default.Download, contentDescription = null, tint = Color.Black)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Save Video to Phone Gallery", color = Color.Black, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
        }

        Text(
            text = "Share Directly to Social Media",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        )

        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.height(180.dp)
        ) {
            items(socialPlatforms) { target ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = KwaiPanelSurface),
                    modifier = Modifier
                        .clickable { onShareToApp(target.name) }
                        .testTag("share_${target.name.lowercase().replace(' ', '_')}")
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(target.icon, fontSize = 24.sp)
                        Text(target.name, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    }
                }
            }
        }

        Button(
            onClick = onHomeClick,
            colors = ButtonDefaults.buttonColors(containerColor = KwaiPanelSurface),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Back to Home Studio", color = Color.White, fontWeight = FontWeight.Bold)
        }
    }
}

data class SocialTarget(val name: String, val icon: String, val brandColor: Color)
