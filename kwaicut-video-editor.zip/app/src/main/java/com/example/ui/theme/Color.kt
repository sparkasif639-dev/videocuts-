package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val KwaiObsidianBg = Color(0xFF1C1B1F)
val KwaiPanelSurface = Color(0xFF25232A)
val KwaiCardSurface = Color(0xFF332D41)
val KwaiBorder = Color(0xFF49454F)

val KwaiMagenta = Color(0xFFD0BCFF)
val OnKwaiMagenta = Color(0xFF381E72)
val KwaiCyan = Color(0xFFCCC2DC)
val KwaiGold = Color(0xFFE8DEF8)
val KwaiPurple = Color(0xFFD0BCFF)

val TextPrimary = Color(0xFFE6E1E9)
val TextSecondary = Color(0xFFCAC4D0)
val TextMuted = Color(0xFF938F99)
