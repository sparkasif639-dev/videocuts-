package com.example.ui

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import android.view.ViewGroup
import android.widget.Toast
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.data.FilterPreset
import com.example.ui.theme.*
import com.example.viewmodel.EditorViewModel
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import com.google.accompanist.permissions.shouldShowRationale
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalPermissionsApi::class, ExperimentalMaterial3Api::class)
@Composable
fun CameraScreen(
    viewModel: EditorViewModel,
    onBack: () -> Unit,
    onOpenEditor: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    // Camera Permissions
    val cameraPermissionState = rememberPermissionState(permission = Manifest.permission.CAMERA)
    val audioPermissionState = rememberPermissionState(permission = Manifest.permission.RECORD_AUDIO)

    LaunchedEffect(Unit) {
        if (!cameraPermissionState.status.isGranted) {
            cameraPermissionState.launchPermissionRequest()
        }
        if (!audioPermissionState.status.isGranted) {
            audioPermissionState.launchPermissionRequest()
        }
    }

    var lensFacing by remember { mutableIntStateOf(CameraSelector.LENS_FACING_BACK) }
    var isFlashOn by remember { mutableStateOf(false) }
    var isRecording by remember { mutableStateOf(false) }
    var recordingDurationSec by remember { mutableLongStateOf(0L) }
    var recordedFileUri by remember { mutableStateOf<Uri?>(null) }
    var selectedFilter by remember { mutableStateOf(FilterPreset.NORMAL) }
    var cameraHasHardwareError by remember { mutableStateOf(false) }

    // Recording timer loop
    LaunchedEffect(isRecording) {
        if (isRecording) {
            recordingDurationSec = 0L
            while (isRecording) {
                delay(1000)
                recordingDurationSec++
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Camera Studio",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("camera_back_button")) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                actions = {
                    // Flash Toggle
                    IconButton(
                        onClick = { isFlashOn = !isFlashOn },
                        modifier = Modifier.testTag("toggle_flash_button")
                    ) {
                        Icon(
                            imageVector = if (isFlashOn) Icons.Default.FlashOn else Icons.Default.FlashOff,
                            contentDescription = "Flash",
                            tint = if (isFlashOn) KwaiGold else Color.White
                        )
                    }

                    // Flip Lens
                    IconButton(
                        onClick = {
                            lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK) {
                                CameraSelector.LENS_FACING_FRONT
                            } else {
                                CameraSelector.LENS_FACING_BACK
                            }
                        },
                        modifier = Modifier.testTag("toggle_camera_lens_button")
                    ) {
                        Icon(imageVector = Icons.Default.Cameraswitch, contentDescription = "Switch Camera", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = KwaiObsidianBg)
            )
        },
        containerColor = KwaiObsidianBg,
        modifier = modifier
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (cameraPermissionState.status.isGranted) {
                // Live CameraX Preview Viewport
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                        .background(Color.Black)
                ) {
                    if (!cameraHasHardwareError) {
                        CameraXPreview(
                            lensFacing = lensFacing,
                            isFlashOn = isFlashOn,
                            onError = { cameraHasHardwareError = true },
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        // Simulation Camera View (For environments without physical camera sensor)
                        SimulationCameraPreview(
                            selectedFilter = selectedFilter,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    // Filter Color Tint Overlay simulation
                    FilterOverlayVisual(
                        filterPreset = selectedFilter,
                        modifier = Modifier.fillMaxSize()
                    )

                    // Recording Indicator Bar
                    if (isRecording) {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = Color.Red.copy(alpha = 0.85f),
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .padding(top = 16.dp)
                                .testTag("recording_status_indicator")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                BlinkingRedDot()
                                Text(
                                    text = formatRecordingTime(recordingDurationSec),
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                                Text("REC", color = Color.White, fontWeight = FontWeight.Black, fontSize = 12.sp)
                            }
                        }
                    }

                    // Filter Selection Carousel (Bottom Overlay)
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 120.dp)
                            .fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Filter: ${selectedFilter.displayName}",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            modifier = Modifier
                                .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                                .padding(horizontal = 12.dp, vertical = 4.dp)
                        )

                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(FilterPreset.entries.toTypedArray()) { preset ->
                                val isSelected = selectedFilter == preset
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (isSelected) KwaiMagenta else Color.Black.copy(alpha = 0.6f),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) KwaiCyan else Color.White.copy(alpha = 0.3f)),
                                    modifier = Modifier
                                        .clickable { selectedFilter = preset }
                                        .testTag("camera_filter_${preset.name.lowercase()}")
                                ) {
                                    Text(
                                        text = preset.displayName,
                                        color = if (isSelected) OnKwaiMagenta else Color.White,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Bottom Shutter / Controls Panel
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .height(110.dp)
                            .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.9f))))
                            .padding(bottom = 16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 32.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Gallery import trigger
                            IconButton(
                                onClick = onBack,
                                modifier = Modifier
                                    .size(48.dp)
                                    .background(KwaiCardSurface, CircleShape)
                            ) {
                                Icon(imageVector = Icons.Default.Collections, contentDescription = "Gallery", tint = Color.White)
                            }

                            // Record / Stop Shutter Button
                            Box(
                                modifier = Modifier
                                    .size(76.dp)
                                    .border(4.dp, Color.White, CircleShape)
                                    .clip(CircleShape)
                                    .background(if (isRecording) Color.Red else KwaiMagenta)
                                    .clickable {
                                        if (isRecording) {
                                            isRecording = false
                                            // Create simulated file output
                                            val file = File(context.cacheDir, "recorded_${System.currentTimeMillis()}.mp4")
                                            file.writeText("sample recorded video stream")
                                            recordedFileUri = Uri.fromFile(file)

                                            viewModel.playerState.videoUriString = recordedFileUri.toString()
                                            viewModel.playerState.filterPreset = selectedFilter
                                            viewModel.createNewProject()
                                            Toast.makeText(context, "Video Recorded Successfully!", Toast.LENGTH_SHORT).show()
                                            onOpenEditor()
                                        } else {
                                            isRecording = true
                                        }
                                    }
                                    .testTag("camera_record_shutter_button"),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isRecording) {
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp)
                                            .background(Color.White, RoundedCornerShape(6.dp))
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.Videocam,
                                        contentDescription = "Record",
                                        tint = OnKwaiMagenta,
                                        modifier = Modifier.size(36.dp)
                                    )
                                }
                            }

                            // Switch Camera or Review
                            IconButton(
                                onClick = {
                                    lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK) {
                                        CameraSelector.LENS_FACING_FRONT
                                    } else {
                                        CameraSelector.LENS_FACING_BACK
                                    }
                                },
                                modifier = Modifier
                                    .size(48.dp)
                                    .background(KwaiCardSurface, CircleShape)
                            ) {
                                Icon(imageVector = Icons.Default.FlipCameraAndroid, contentDescription = "Flip", tint = Color.White)
                            }
                        }
                    }
                }
            } else {
                // Permission Request Fallback View
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CameraAlt,
                        contentDescription = null,
                        tint = KwaiMagenta,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Camera Permission Required",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "KwaiCut needs access to your camera and microphone to record video clips.",
                        color = TextSecondary,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Button(
                        onClick = {
                            cameraPermissionState.launchPermissionRequest()
                            audioPermissionState.launchPermissionRequest()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = KwaiMagenta),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text("Grant Camera Permission", color = OnKwaiMagenta, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun CameraXPreview(
    lensFacing: Int,
    isFlashOn: Boolean,
    onError: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    AndroidView(
        factory = { ctx ->
            PreviewView(ctx).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                scaleType = PreviewView.ScaleType.FILL_CENTER
            }
        },
        update = { previewView ->
            val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
            cameraProviderFuture.addListener({
                try {
                    val cameraProvider = cameraProviderFuture.get()
                    val preview = Preview.Builder().build().also {
                        it.surfaceProvider = previewView.surfaceProvider
                    }

                    val cameraSelector = CameraSelector.Builder()
                        .requireLensFacing(lensFacing)
                        .build()

                    cameraProvider.unbindAll()
                    val camera = cameraProvider.bindToLifecycle(
                        lifecycleOwner,
                        cameraSelector,
                        preview
                    )

                    camera.cameraControl.enableTorch(isFlashOn)
                } catch (e: Exception) {
                    Log.e("CameraX", "Error binding camera preview", e)
                    onError()
                }
            }, ContextCompat.getMainExecutor(context))
        },
        modifier = modifier
    )
}

@Composable
fun SimulationCameraPreview(
    selectedFilter: FilterPreset,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "CameraSim")
    val gridOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 100f,
        animationSpec = infiniteRepeatable(tween(3000, easing = LinearEasing)),
        label = "Grid"
    )

    Box(
        modifier = modifier
            .background(Brush.radialGradient(listOf(KwaiCardSurface, KwaiObsidianBg)))
    ) {
        // Grid lines to simulate camera viewfinder
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            val thirdW = width / 3f
            val thirdH = height / 3f

            // Rule of thirds lines
            drawLine(Color.White.copy(alpha = 0.2f), Offset(thirdW, 0f), Offset(thirdW, height), strokeWidth = 1f)
            drawLine(Color.White.copy(alpha = 0.2f), Offset(thirdW * 2, 0f), Offset(thirdW * 2, height), strokeWidth = 1f)
            drawLine(Color.White.copy(alpha = 0.2f), Offset(0f, thirdH), Offset(width, thirdH), strokeWidth = 1f)
            drawLine(Color.White.copy(alpha = 0.2f), Offset(0f, thirdH * 2), Offset(width, thirdH * 2), strokeWidth = 1f)
        }

        Column(
            modifier = Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Videocam,
                contentDescription = null,
                tint = KwaiMagenta,
                modifier = Modifier.size(56.dp)
            )
            Text("Live Viewfinder Ready", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("4K HDR Sensor • 60 FPS Optical Lens", color = TextSecondary, fontSize = 12.sp)
        }
    }
}

@Composable
fun FilterOverlayVisual(
    filterPreset: FilterPreset,
    modifier: Modifier = Modifier
) {
    val overlayColor = when (filterPreset) {
        FilterPreset.CYBERPUNK -> KwaiCyan.copy(alpha = 0.25f)
        FilterPreset.VINTAGE_VHS -> Color(0xFFD2B48C).copy(alpha = 0.25f)
        FilterPreset.CINEMATIC_GOLD -> KwaiGold.copy(alpha = 0.20f)
        FilterPreset.SOFT_PINK -> KwaiMagenta.copy(alpha = 0.20f)
        FilterPreset.NEO_NOIR -> Color.Black.copy(alpha = 0.40f)
        FilterPreset.RETRO_80S -> Color(0xFFFF00FF).copy(alpha = 0.25f)
        else -> Color.Transparent
    }

    if (overlayColor != Color.Transparent) {
        Box(modifier = modifier.background(overlayColor))
    }
}

@Composable
fun BlinkingRedDot() {
    val infiniteTransition = rememberInfiniteTransition(label = "RedDot")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 0.2f,
        animationSpec = infiniteRepeatable(tween(800), repeatMode = RepeatMode.Reverse),
        label = "Alpha"
    )

    Box(
        modifier = Modifier
            .size(10.dp)
            .background(Color.Red.copy(alpha = alpha), CircleShape)
    )
}

private fun formatRecordingTime(sec: Long): String {
    val m = sec / 60
    val s = sec % 60
    return String.format(Locale.US, "%02d:%02d", m, s)
}
