package com.example.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SampleData
import com.example.data.db.ProjectEntity
import com.example.ui.theme.*
import com.example.viewmodel.EditorViewModel

data class QuickToolItem(
    val id: String,
    val title: String,
    val icon: ImageVector,
    val badge: String? = null,
    val onClick: () -> Unit
)

enum class HomeNavTab(val title: String, val icon: ImageVector) {
    EDIT("Edit", Icons.Default.ContentCut),
    DISCOVER("Discover", Icons.Default.Explore),
    AI_LAB("AI Lab", Icons.Default.AutoAwesome),
    PROJECTS("Projects", Icons.Default.Folder),
    INBOX("Inbox", Icons.Default.Notifications),
    ME("Me", Icons.Default.Person)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: EditorViewModel,
    onOpenEditor: () -> Unit,
    onOpenTemplates: () -> Unit,
    onOpenCamera: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val savedProjects by viewModel.savedProjects.collectAsState()
    var selectedBottomTab by remember { mutableStateOf(HomeNavTab.EDIT) }
    var projectToDelete by remember { mutableStateOf<ProjectEntity?>(null) }
    var activeToolInfoDialog by remember { mutableStateOf<String?>(null) }

    // System gallery picker for user media import
    val mediaPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            viewModel.createNewProject()
            onOpenEditor()
        }
    }

    Scaffold(
        bottomBar = {
            BottomNavigationBar(
                selectedTab = selectedBottomTab,
                onTabSelected = { selectedBottomTab = it }
            )
        },
        containerColor = Color(0xFFF6F8FC),
        modifier = modifier
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = innerPadding.calculateBottomPadding())
        ) {
            when (selectedBottomTab) {
                HomeNavTab.EDIT -> {
                    MainEditPageContent(
                        savedProjects = savedProjects,
                        onOpenEditor = onOpenEditor,
                        onOpenTemplates = onOpenTemplates,
                        onOpenCamera = onOpenCamera,
                        onImportMedia = { mediaPickerLauncher.launch("video/*") },
                        onSelectProject = { project ->
                            viewModel.loadProject(project)
                            onOpenEditor()
                        },
                        onShowToolInfo = { toolName ->
                            activeToolInfoDialog = toolName
                        },
                        viewModel = viewModel
                    )
                }
                HomeNavTab.PROJECTS -> {
                    SavedProjectsTabContent(
                        savedProjects = savedProjects,
                        onSelectProject = { project ->
                            viewModel.loadProject(project)
                            onOpenEditor()
                        },
                        onDeleteProject = { projectToDelete = it },
                        onCreateNew = {
                            viewModel.createNewProject()
                            onOpenEditor()
                        }
                    )
                }
                else -> {
                    GenericTabPlaceholderContent(
                        tab = selectedBottomTab,
                        onGoToEdit = { selectedBottomTab = HomeNavTab.EDIT },
                        onOpenEditor = {
                            viewModel.createNewProject()
                            onOpenEditor()
                        },
                        onOpenTemplates = onOpenTemplates
                    )
                }
            }
        }
    }

    // Delete confirmation modal
    projectToDelete?.let { project ->
        AlertDialog(
            onDismissRequest = { projectToDelete = null },
            title = { Text("Delete Project?", color = Color.Black, fontWeight = FontWeight.Bold) },
            text = { Text("Are you sure you want to remove '${project.title}'?", color = Color.DarkGray) },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteProject(project.id)
                        projectToDelete = null
                    }
                ) {
                    Text("Delete", color = Color.Red, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { projectToDelete = null }) {
                    Text("Cancel", color = Color.Gray)
                }
            },
            containerColor = Color.White
        )
    }

    // Quick Tool Info Modal
    activeToolInfoDialog?.let { toolName ->
        AlertDialog(
            onDismissRequest = { activeToolInfoDialog = null },
            title = { Text(toolName, color = Color.Black, fontWeight = FontWeight.Bold) },
            text = { Text("The '$toolName' studio module is ready. Select media or tap 'Launch' to open in editor timeline.", color = Color.DarkGray) },
            confirmButton = {
                Button(
                    onClick = {
                        activeToolInfoDialog = null
                        viewModel.createNewProject()
                        onOpenEditor()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Black)
                ) {
                    Text("Launch Tool", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { activeToolInfoDialog = null }) {
                    Text("Dismiss", color = Color.Gray)
                }
            },
            containerColor = Color.White
        )
    }
}

@Composable
fun MainEditPageContent(
    savedProjects: List<ProjectEntity>,
    onOpenEditor: () -> Unit,
    onOpenTemplates: () -> Unit,
    onOpenCamera: () -> Unit,
    onImportMedia: () -> Unit,
    onSelectProject: (ProjectEntity) -> Unit,
    onShowToolInfo: (String) -> Unit,
    viewModel: EditorViewModel
) {
    // Define the list of 14 tools from the screenshot
    val toolsList = remember {
        listOf(
            QuickToolItem("1", "Post template", Icons.Default.PlayCircleOutline, onClick = onOpenTemplates),
            QuickToolItem("2", "AutoCut", Icons.Default.AutoAwesome, onClick = onOpenTemplates),
            QuickToolItem("3", "Retouch", Icons.Default.Face, onClick = { onShowToolInfo("Retouch & Face Beauty") }),
            QuickToolItem("4", "Photo tools", Icons.Default.Image, onClick = onImportMedia),
            QuickToolItem("5", "Shoot and record", Icons.Default.Videocam, onClick = onOpenCamera),
            QuickToolItem("6", "Auto enhance", Icons.Default.AutoFixHigh, onClick = { onShowToolInfo("Auto Enhance AI") }),
            QuickToolItem("7", "Auto captions", Icons.Default.ClosedCaption, onClick = {
                viewModel.createNewProject()
                onOpenEditor()
            }),
            QuickToolItem("8", "Remove background", Icons.Default.Portrait, onClick = { onShowToolInfo("Remove Background AI") }),
            QuickToolItem("9", "Space", Icons.Default.Cloud, onClick = { onShowToolInfo("Cloud Studio Space") }),
            QuickToolItem("10", "Adjust speed", Icons.Default.Speed, onClick = {
                viewModel.createNewProject()
                onOpenEditor()
            }),
            QuickToolItem("11", "Marketing tools", Icons.Default.ShoppingBag, onClick = { onShowToolInfo("Marketing & Promo Tools") }),
            QuickToolItem("12", "Record", Icons.Default.Mic, onClick = onOpenCamera),
            QuickToolItem("13", "Desktop editor", Icons.Default.Computer, badge = "Free perks", onClick = { onShowToolInfo("Desktop Sync Editor") }),
            QuickToolItem("14", "All tools (18)", Icons.Default.GridView, onClick = { onShowToolInfo("All Studio Tools") })
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // 1. Top Vibrant Blue Gradient Header Block
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFF1565C0), // Deep blue
                                Color(0xFF1E88E5), // Sky blue
                                Color(0xFF42A5F5), // Light blue
                                Color(0xFFF6F8FC)  // Transitions into content background
                            )
                        )
                    )
                    .padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 12.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    // Top Navigation / Header Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Import",
                            color = Color.White.copy(alpha = 0.95f),
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier
                                .clickable { onImportMedia() }
                                .testTag("top_import_button")
                        )

                        Surface(
                            shape = CircleShape,
                            color = Color.White.copy(alpha = 0.22f),
                            modifier = Modifier
                                .size(36.dp)
                                .clickable { onShowToolInfo("Search Studio Tools & Clips") }
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Search,
                                    contentDescription = "Search",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }

                    // Hero Headline text
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = "Video create",
                            color = Color.White.copy(alpha = 0.85f),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Normal
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "Get started",
                                color = Color.White,
                                fontSize = 26.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Icon(
                                imageVector = Icons.Default.ChevronRight,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }

                    // 2. Action Cards Row (New Video & Edit Photo)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Left Card: New video
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = Color.White,
                            shadowElevation = 2.dp,
                            modifier = Modifier
                                .weight(1.3f)
                                .height(125.dp)
                                .clickable {
                                    viewModel.createNewProject()
                                    onOpenEditor()
                                }
                                .testTag("new_video_main_card")
                        ) {
                            Column(
                                modifier = Modifier.fillMaxSize(),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = Color.Black,
                                    modifier = Modifier.size(44.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.Add,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "New video",
                                    color = Color(0xFF111827),
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Right Card: Edit photo
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = Color.White,
                            shadowElevation = 2.dp,
                            modifier = Modifier
                                .weight(1f)
                                .height(125.dp)
                                .clickable { onImportMedia() }
                                .testTag("edit_photo_card")
                        ) {
                            Box(modifier = Modifier.fillMaxSize()) {
                                // Nano Banana Badge on top right
                                Surface(
                                    shape = RoundedCornerShape(bottomStart = 8.dp, topEnd = 20.dp),
                                    color = Color(0xFFE2EDF9),
                                    modifier = Modifier.align(Alignment.TopEnd)
                                ) {
                                    Text(
                                        text = "Nano Banana 2 Lite",
                                        color = Color(0xFF1E3A8A),
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }

                                Column(
                                    modifier = Modifier.fillMaxSize(),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Surface(
                                        shape = CircleShape,
                                        color = Color.Black,
                                        modifier = Modifier.size(44.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.Default.Add,
                                                contentDescription = null,
                                                tint = Color.White,
                                                modifier = Modifier.size(24.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text(
                                        text = "Edit photo",
                                        color = Color(0xFF111827),
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    // 3. Horizontal Project Thumbnails Row
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(vertical = 4.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // Demo project dates matching screenshot: 0730-01, 0729-01, 0728-01, 0727-02, 0726-02
                        val demoClips = listOf(
                            Pair("0730-01", Color(0xFF1E293B)),
                            Pair("0729-01", Color(0xFF0F172A)),
                            Pair("0728-01", Color(0xFF020617)),
                            Pair("0727-02", Color(0xFF1C1917)),
                            Pair("0726-02", Color(0xFF111827))
                        )

                        items(demoClips) { clip ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = clip.second,
                                modifier = Modifier
                                    .size(76.dp)
                                    .clickable {
                                        viewModel.createNewProject()
                                        onOpenEditor()
                                    }
                            ) {
                                Box(modifier = Modifier.fillMaxSize()) {
                                    // Visual gradient texture
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .background(
                                                Brush.linearGradient(
                                                    listOf(
                                                        Color.White.copy(alpha = 0.1f),
                                                        Color.Transparent
                                                    )
                                                )
                                            )
                                    )

                                    // Scissors tag at bottom left
                                    Surface(
                                        shape = RoundedCornerShape(topEnd = 6.dp),
                                        color = Color.Black.copy(alpha = 0.65f),
                                        modifier = Modifier.align(Alignment.BottomStart)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.ContentCut,
                                                contentDescription = null,
                                                tint = Color.White,
                                                modifier = Modifier.size(9.dp)
                                            )
                                            Text(
                                                text = clip.first,
                                                color = Color.White,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Rightmost Expand Button Card (>)
                        item {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color(0xFFB0C4DE),
                                modifier = Modifier
                                    .size(76.dp)
                                    .clickable {
                                        viewModel.createNewProject()
                                        onOpenEditor()
                                    }
                            ) {
                                Box(
                                    modifier = Modifier.fillMaxSize(),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ChevronRight,
                                        contentDescription = "More",
                                        tint = Color.White,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 4. Grid of Tool Items (3 Columns)
        item {
            Surface(
                color = Color.White,
                shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 20.dp),
                    verticalArrangement = Arrangement.spacedBy(22.dp)
                ) {
                    val rows = toolsList.chunked(3)
                    rows.forEach { rowItems ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            rowItems.forEach { tool ->
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { tool.onClick() }
                                        .testTag("tool_item_${tool.id}")
                                ) {
                                    Box(contentAlignment = Alignment.TopCenter) {
                                        Icon(
                                            imageVector = tool.icon,
                                            contentDescription = tool.title,
                                            tint = Color(0xFF1E293B),
                                            modifier = Modifier.size(28.dp)
                                        )

                                        // Badge if applicable (e.g. "Free perks")
                                        if (tool.badge != null) {
                                            Surface(
                                                shape = RoundedCornerShape(4.dp),
                                                color = Color(0xFF00C853),
                                                modifier = Modifier.offset(y = (-10).dp)
                                            ) {
                                                Text(
                                                    text = tool.badge,
                                                    color = Color.White,
                                                    fontSize = 8.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                )
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Text(
                                        text = tool.title,
                                        color = Color(0xFF1F2937),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        maxLines = 1
                                    )
                                }
                            }

                            // Fill remaining empty columns if last row has fewer than 3 items
                            if (rowItems.size < 3) {
                                repeat(3 - rowItems.size) {
                                    Spacer(modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SavedProjectsTabContent(
    savedProjects: List<ProjectEntity>,
    onSelectProject: (ProjectEntity) -> Unit,
    onDeleteProject: (ProjectEntity) -> Unit,
    onCreateNew: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "My Projects",
                color = Color.Black,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )

            Button(
                onClick = onCreateNew,
                colors = ButtonDefaults.buttonColors(containerColor = KwaiMagenta),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = null, tint = OnKwaiMagenta)
                Spacer(modifier = Modifier.width(4.dp))
                Text("New Draft", color = OnKwaiMagenta, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (savedProjects.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(imageVector = Icons.Default.FolderOpen, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(56.dp))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("No saved draft projects yet", color = Color.Gray, fontSize = 14.sp)
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(savedProjects) { project ->
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = Color.White,
                        shadowElevation = 1.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectProject(project) }
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(60.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0xFF1E293B)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(imageVector = Icons.Default.Movie, contentDescription = null, tint = KwaiCyan)
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = project.title, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.Black)
                                Text(text = "Filter: ${project.filterPresetName}", fontSize = 12.sp, color = Color.Gray)
                            }

                            IconButton(onClick = { onDeleteProject(project) }) {
                                Icon(imageVector = Icons.Default.DeleteOutline, contentDescription = "Delete", tint = Color.Gray)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun GenericTabPlaceholderContent(
    tab: HomeNavTab,
    onGoToEdit: () -> Unit,
    onOpenEditor: () -> Unit,
    onOpenTemplates: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = tab.icon,
            contentDescription = null,
            tint = Color(0xFF1E88E5),
            modifier = Modifier.size(64.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = tab.title,
            color = Color.Black,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Explore trending creators, AI studio generators, and community templates.",
            color = Color.Gray,
            fontSize = 14.sp,
            modifier = Modifier.padding(horizontal = 24.dp)
        )

        Spacer(modifier = Modifier.height(24.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(
                onClick = onGoToEdit,
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Back to Edit")
            }

            Button(
                onClick = onOpenTemplates,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E88E5)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Browse Templates", color = Color.White)
            }
        }
    }
}

@Composable
fun BottomNavigationBar(
    selectedTab: HomeNavTab,
    onTabSelected: (HomeNavTab) -> Unit
) {
    Surface(
        color = Color.White,
        shadowElevation = 8.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            HomeNavTab.entries.forEach { tab ->
                val isSelected = selectedTab == tab
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clickable { onTabSelected(tab) }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                        .testTag("nav_bottom_tab_${tab.name.lowercase()}")
                ) {
                    Icon(
                        imageVector = tab.icon,
                        contentDescription = tab.title,
                        tint = if (isSelected) Color.Black else Color(0xFF94A3B8),
                        modifier = Modifier.size(24.dp)
                    )

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = tab.title,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) Color.Black else Color(0xFF94A3B8)
                    )
                }
            }
        }
    }
}
