package com.example.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SampleData
import com.example.data.VideoTemplate
import com.example.ui.theme.*
import com.example.viewmodel.EditorViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TemplatesScreen(
    viewModel: EditorViewModel,
    onBack: () -> Unit,
    onOpenEditor: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedCategory by remember { mutableStateOf("All") }
    var templateToPreview by remember { mutableStateOf<VideoTemplate?>(null) }

    val categories = listOf("All", "Trending Reels", "Travel & Vlog", "Vintage FX", "Music Sync", "Cinematic")

    val filteredTemplates = if (selectedCategory == "All") {
        SampleData.templates
    } else {
        SampleData.templates.filter { it.category == selectedCategory }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, tint = KwaiGold)
                        Text(
                            text = "Viral Video Templates",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("templates_back_button")) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = KwaiObsidianBg)
            )
        },
        containerColor = KwaiObsidianBg,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Category Chips Row
            ScrollableTabRow(
                selectedTabIndex = categories.indexOf(selectedCategory).coerceAtLeast(0),
                containerColor = KwaiObsidianBg,
                edgePadding = 0.dp
            ) {
                categories.forEach { category ->
                    Tab(
                        selected = selectedCategory == category,
                        onClick = { selectedCategory = category },
                        text = {
                            Text(
                                text = category,
                                color = if (selectedCategory == category) KwaiMagenta else TextSecondary,
                                fontWeight = if (selectedCategory == category) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    )
                }
            }

            // Grid of Templates
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredTemplates) { template ->
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = KwaiPanelSurface),
                        modifier = Modifier
                            .height(260.dp)
                            .clickable { templateToPreview = template }
                            .testTag("template_grid_item_${template.id}")
                    ) {
                        Box(modifier = Modifier.fillMaxSize()) {
                            if (template.coverDrawableRes != null) {
                                Image(
                                    painter = painterResource(id = template.coverDrawableRes),
                                    contentDescription = template.title,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Brush.verticalGradient(listOf(KwaiMagenta, KwaiPanelSurface)))
                                )
                            }

                            // Dark Gradient Overlay
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.verticalGradient(
                                            colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f)),
                                            startY = 150f
                                        )
                                    )
                            )

                            // Quick Use Button
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = KwaiMagenta,
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, tint = OnKwaiMagenta, modifier = Modifier.size(12.dp))
                                    Text("Use", color = OnKwaiMagenta, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            // Info at bottom
                            Column(
                                modifier = Modifier
                                    .align(Alignment.BottomStart)
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = template.title,
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 2
                                )

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.MusicNote, contentDescription = null, tint = KwaiCyan, modifier = Modifier.size(12.dp))
                                    Text(template.musicTrack, color = KwaiCyan, fontSize = 11.sp, maxLines = 1)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Template Detail & Launch Dialog
    templateToPreview?.let { template ->
        AlertDialog(
            onDismissRequest = { templateToPreview = null },
            title = {
                Text(template.title, color = Color.White, fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Filter Preset: ${template.filterPreset.displayName}", color = TextSecondary)
                    Text("Magic Effect: ${template.magicEffect.displayName}", color = TextSecondary)
                    Text("Audio Track: ${template.musicTrack}", color = KwaiCyan)
                    Text("Sample Text: ${template.textSample}", color = KwaiGold)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.applyTemplate(template)
                        templateToPreview = null
                        onOpenEditor()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = KwaiMagenta)
                ) {
                    Text("1-Tap Use Template", fontWeight = FontWeight.Bold, color = OnKwaiMagenta)
                }
            },
            dismissButton = {
                TextButton(onClick = { templateToPreview = null }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = KwaiPanelSurface
        )
    }
}
