package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val KwaiCutColorScheme = darkColorScheme(
    primary = KwaiMagenta,
    onPrimary = OnKwaiMagenta,
    primaryContainer = KwaiMagenta.copy(alpha = 0.2f),
    onPrimaryContainer = KwaiMagenta,
    secondary = KwaiCyan,
    onSecondary = Color(0xFF332D41),
    secondaryContainer = KwaiCyan.copy(alpha = 0.15f),
    onSecondaryContainer = KwaiCyan,
    tertiary = KwaiGold,
    background = KwaiObsidianBg,
    onBackground = TextPrimary,
    surface = KwaiPanelSurface,
    onSurface = TextPrimary,
    surfaceVariant = KwaiCardSurface,
    onSurfaceVariant = TextSecondary,
    outline = KwaiBorder
)

@Composable
fun KwaiCutTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = KwaiCutColorScheme,
        typography = Typography,
        content = content
    )
}
