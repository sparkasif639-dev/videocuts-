package com.example.ui

import java.util.Locale
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*
import com.example.video.CanvasVideoPlayer
import com.example.video.VideoPlayerState
import com.example.viewmodel.EditorTab
import com.example.viewmodel.EditorViewModel
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(
    viewModel: EditorViewModel,
    onBack: () -> Unit,
    onOpenExport: () -> Unit,
    modifier: Modifier = Modifier
) {
    val playerState = viewModel.playerState
    var showResolutionMenu by remember { mutableStateOf(false) }
    var showExportConfigDialog by remember { mutableStateOf(false) }
    var showHelpDialog by remember { mutableStateOf(false) }
    var showDraftZipExportMsg by remember { mutableStateOf(false) }

    if (showExportConfigDialog) {
        ExportConfigurationDialog(
            viewModel = viewModel,
            onDismiss = { showExportConfigDialog = false },
            onConfirmExport = {
                showExportConfigDialog = false
                onOpenExport()
            }
        )
    }

    if (showHelpDialog) {
        AlertDialog(
            onDismissRequest = { showHelpDialog = false },
            title = { Text("Editing Guide", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "• Scrub timeline to preview frames\n" +
                    "• Tap tools at bottom to add Subtitles, Audio, Effects & Filters\n" +
                    "• Tap Export on top right when ready to render HD video",
                    color = TextSecondary,
                    fontSize = 14.sp
                )
            },
            confirmButton = {
                TextButton(onClick = { showHelpDialog = false }) {
                    Text("Got it", color = KwaiMagenta, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = KwaiPanelSurface
        )
    }

    if (showDraftZipExportMsg) {
        AlertDialog(
            onDismissRequest = { showDraftZipExportMsg = false },
            title = { Text("Export Draft Zip", color = Color.White, fontWeight = FontWeight.Bold) },
            text = { Text("Exporting project draft archive with all source clips and timeline metadata...", color = TextSecondary) },
            confirmButton = {
                Button(
                    onClick = {
                        showDraftZipExportMsg = false
                        onOpenExport()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = KwaiMagenta)
                ) {
                    Text("Confirm Zip Export", color = OnKwaiMagenta)
                }
            },
            containerColor = KwaiPanelSurface
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(end = 4.dp)
                        ) {
                            // Auto-Save Status Badge (Room Database 30s auto-save)
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color(0xFF1E293B),
                                modifier = Modifier.testTag("autosave_status_badge")
                            ) {
                                val autoSaveLabel = when {
                                    viewModel.isAutoSaving -> "Saving..."
                                    viewModel.lastAutoSaveTime != null -> "Auto-saved"
                                    else -> "Auto-save active"
                                }
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = if (viewModel.isAutoSaving) Icons.Default.Sync else Icons.Default.CloudDone,
                                        contentDescription = "Auto Save Status",
                                        tint = if (viewModel.isAutoSaving) KwaiCyan else Color(0xFF4ADE80),
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Text(
                                        text = autoSaveLabel,
                                        color = Color.LightGray,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }

                            // Resolution Dropdown Badge e.g. "720P ▼"
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color(0xFF27272A),
                                modifier = Modifier
                                    .clickable { showResolutionMenu = true }
                                    .testTag("resolution_picker_badge")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = viewModel.exportResolution.label.split(" ").firstOrNull() ?: "720P",
                                        color = Color.White,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Icon(
                                        imageVector = Icons.Default.ArrowDropDown,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }

                                DropdownMenu(
                                    expanded = showResolutionMenu,
                                    onDismissRequest = { showResolutionMenu = false },
                                    modifier = Modifier.background(KwaiPanelSurface)
                                ) {
                                    ExportResolution.entries.forEach { res ->
                                        DropdownMenuItem(
                                            text = {
                                                Text(
                                                    text = "${res.label} (${res.width}x${res.height})",
                                                    color = Color.White,
                                                    fontSize = 13.sp
                                                )
                                            },
                                            onClick = {
                                                viewModel.exportResolution = res
                                                showResolutionMenu = false
                                            }
                                        )
                                    }
                                }
                            }

                            // Quick Save to Gallery Icon Button
                            IconButton(
                                onClick = { showExportConfigDialog = true },
                                modifier = Modifier.testTag("editor_top_gallery_export_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Download,
                                    contentDescription = "Save to Gallery",
                                    tint = KwaiGold,
                                    modifier = Modifier.size(22.dp)
                                )
                            }

                            // Light Sky Blue "Export" Pill Button
                            Button(
                                onClick = { showExportConfigDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC5E8FA)),
                                shape = RoundedCornerShape(12.dp),
                                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                                modifier = Modifier.testTag("done_export_button")
                            ) {
                                Text(
                                    text = "Export",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = Color(0xFF0F172A)
                                )
                            }
                        }
                    }
                },
                navigationIcon = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        // Close / Back Button (X)
                        IconButton(onClick = onBack, modifier = Modifier.testTag("editor_back_button")) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.White, modifier = Modifier.size(24.dp))
                        }

                        // Search Icon (Q)
                        IconButton(onClick = { showHelpDialog = true }, modifier = Modifier.testTag("editor_help_button")) {
                            Icon(imageVector = Icons.Default.Search, contentDescription = "Search", tint = Color.White, modifier = Modifier.size(22.dp))
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Black)
            )
        },
        containerColor = Color.Black,
        modifier = modifier
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Floating "Export Draft Zip" badge top right below top bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 2.dp),
                    horizontalArrangement = Arrangement.End
                ) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFF27272A).copy(alpha = 0.85f),
                        modifier = Modifier.clickable { showDraftZipExportMsg = true }
                    ) {
                        Text(
                            text = "Export Draft Zip",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                }

                // 1. Center Interactive Canvas Viewport
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    CanvasVideoPlayer(
                        playerState = playerState,
                        modifier = Modifier.fillMaxSize()
                    )

                    // Undo / Redo Toast Banner
                    LaunchedEffect(playerState.actionNotice) {
                        if (playerState.actionNotice != null) {
                            delay(2000)
                            playerState.actionNotice = null
                        }
                    }

                    if (playerState.actionNotice != null) {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = Color(0xFF0F172A).copy(alpha = 0.92f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, KwaiCyan),
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .padding(top = 12.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.History,
                                    contentDescription = null,
                                    tint = KwaiCyan,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = playerState.actionNotice ?: "",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // 2. Control Bar below Video Preview
                VideoOverlayControlBar(playerState = playerState)

                // Time ruler ticks line
                TimeRulerTicksHeader(playerState = playerState)

                // 3. Multi-Track Timeline Section
                TimelineSection(playerState = playerState)

                // 4. Feature Tools Inspector Panel (if active tab selected)
                InspectorToolPanel(
                    viewModel = viewModel,
                    playerState = playerState
                )

                // 5. Bottom Navigation Tool Tabs
                BottomToolTabsBar(
                    activeTab = viewModel.activeTab,
                    onTabSelect = { viewModel.activeTab = it }
                )
            }
        }
    }
}

@Composable
fun VideoOverlayControlBar(
    playerState: VideoPlayerState,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(Color.Black)
            .padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // Left: Fullscreen Expand Icon [ ]
        IconButton(
            onClick = {},
            modifier = Modifier.size(28.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Fullscreen,
                contentDescription = "Fullscreen",
                tint = Color.White,
                modifier = Modifier.size(20.dp)
            )
        }

        // Center: Play Button ▶
        IconButton(
            onClick = { playerState.togglePlay() },
            modifier = Modifier
                .size(32.dp)
                .testTag("viewport_play_button")
        ) {
            Icon(
                imageVector = if (playerState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = "Play",
                tint = Color.White,
                modifier = Modifier.size(24.dp)
            )
        }

        // Right Actions: Keyframe [+ ON], Undo ↺, Redo ↻
        Row(
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Keyframe icon button with [+ ON] badge
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .clickable { playerState.isKeyframeAdded = !playerState.isKeyframeAdded }
                    .padding(2.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.CropFree,
                    contentDescription = "Keyframe",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = if (playerState.isKeyframeAdded) "+ON" else "+",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Undo ↺
            IconButton(
                onClick = { playerState.undo() },
                enabled = playerState.canUndo,
                modifier = Modifier
                    .size(28.dp)
                    .testTag("undo_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Undo,
                    contentDescription = "Undo",
                    tint = if (playerState.canUndo) Color.White else Color.Gray.copy(alpha = 0.4f),
                    modifier = Modifier.size(18.dp)
                )
            }

            // Redo ↻
            IconButton(
                onClick = { playerState.redo() },
                enabled = playerState.canRedo,
                modifier = Modifier
                    .size(28.dp)
                    .testTag("redo_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Redo,
                    contentDescription = "Redo",
                    tint = if (playerState.canRedo) Color.White else Color.Gray.copy(alpha = 0.4f),
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
fun TimeRulerTicksHeader(playerState: VideoPlayerState) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.Black)
            .padding(horizontal = 12.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // Time Indicator Text (00:00 / 00:20)
        Text(
            text = "${formatTimecodeShort(playerState.currentTimeMs)} / ${formatTimecodeShort(playerState.totalDurationMs)}",
            color = Color.LightGray,
            fontSize = 11.sp,
            fontWeight = FontWeight.Normal
        )

        // Time Ruler Ticks Text (00:00 • 00:01 • 00:02 • 00:03 • 00:04 •)
        Text(
            text = "00:00  •  00:01  •  00:02  •  00:03  •  00:04  •",
            color = Color.DarkGray,
            fontSize = 11.sp,
            fontWeight = FontWeight.Normal
        )
    }
}

@Composable
fun TimelineSection(playerState: VideoPlayerState) {
    val scrollState = rememberScrollState()

    Surface(
        color = Color.Black,
        modifier = Modifier
            .fillMaxWidth()
            .height(200.dp)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Row(modifier = Modifier.fillMaxSize()) {
                // Left Fixed Controls Column
                Column(
                    modifier = Modifier
                        .width(72.dp)
                        .fillMaxHeight()
                        .background(Color.Black)
                        .padding(vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Mute Clip Button
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clickable { playerState.isAudioMuted = !playerState.isAudioMuted }
                            .testTag("mute_audio_button")
                    ) {
                        Icon(
                            imageVector = if (playerState.isAudioMuted) Icons.Default.VolumeOff else Icons.Default.VolumeMute,
                            contentDescription = "Mute clip",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Mute\nclip",
                            color = Color.White,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Normal
                        )
                    }

                    // Cover Button Box
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clickable { playerState.coverImageName = "Cover Frame #${(playerState.currentTimeMs / 1000)}" }
                            .testTag("select_cover_button")
                    ) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFF27272A),
                            modifier = Modifier.size(44.dp, 32.dp)
                        ) {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Cover",
                                    tint = Color.White,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = "Cover",
                                    color = Color.White,
                                    fontSize = 9.sp,
                                    modifier = Modifier.align(Alignment.BottomCenter)
                                )
                            }
                        }
                    }

                    // Audio track icon ♪
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color(0xFF1E1E24),
                        modifier = Modifier.size(32.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.MusicNote,
                                contentDescription = "Audio",
                                tint = Color.Gray,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    // Text track icon T
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color(0xFF1E1E24),
                        modifier = Modifier.size(32.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Title,
                                contentDescription = "Text",
                                tint = Color.Gray,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                // Right Scrollable Timeline Track Area
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .horizontalScroll(scrollState)
                ) {
                    Column(
                        modifier = Modifier
                            .width(850.dp)
                            .fillMaxHeight()
                            .padding(top = 4.dp, start = 8.dp, end = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Main Video Clip Thumbnail Strip Track
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            // Thumbnail Strip Container
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = Color(0xFF1E2130),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.3f)),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxSize(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    repeat(8) { index ->
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .fillMaxHeight()
                                                .background(
                                                    if (index % 2 == 0) Color(0xFF2B3045) else Color(0xFF1B1E2B)
                                                )
                                                .border(0.5.dp, Color.Black)
                                        )
                                    }
                                }
                            }

                            // White Plus Button to Add Clip (+)
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = Color.White,
                                modifier = Modifier
                                    .size(32.dp, 44.dp)
                                    .clickable { playerState.totalDurationMs += 4000L }
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = "Add Clip",
                                        tint = Color.Black,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }

                        // Track 2: "+ Add audio" Track Bar
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFF1C1C1E),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(28.dp)
                                .clickable {
                                    playerState.selectedAudioTrack = SampleData.audioTracks.first()
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = null,
                                    tint = Color.Gray,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = playerState.selectedAudioTrack?.title ?: "Add audio",
                                    color = Color.Gray,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        // Track 3: "+ Add text" Track Bar
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFF1C1C1E),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(28.dp)
                                .clickable {
                                    playerState.textOverlays.add(TextOverlay(text = "Subtitle"))
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = null,
                                    tint = Color.Gray,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = if (playerState.textOverlays.isNotEmpty()) playerState.textOverlays.first().text else "Add text",
                                    color = Color.Gray,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    // Vertical White Playhead Scrubber Line in Center
                    Box(
                        modifier = Modifier
                            .align(Alignment.CenterStart)
                            .padding(start = 100.dp)
                            .width(2.dp)
                            .fillMaxHeight()
                            .background(Color.White)
                    )
                }
            }

            // AI Lab Floating Circular Action Button on bottom left
            Surface(
                shape = CircleShape,
                color = Color(0xFF1E293B),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00E5FF)),
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(start = 12.dp, bottom = 8.dp)
                    .size(36.dp)
                    .clickable { playerState.magicEffect = MagicEffect.LIGHT_LEAKS }
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "AI Lab",
                        tint = Color(0xFF00E5FF),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun InspectorToolPanel(
    viewModel: EditorViewModel,
    playerState: VideoPlayerState
) {
    Surface(
        color = Color(0xFF121214),
        modifier = Modifier
            .fillMaxWidth()
            .height(110.dp)
    ) {
        Box(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
            when (viewModel.activeTab) {
                EditorTab.EDIT -> EditToolPanel(playerState)
                EditorTab.AUDIO -> AudioToolPanel(playerState)
                EditorTab.TEXT -> TextToolPanel(playerState)
                EditorTab.EFFECTS -> MagicEffectsToolPanel(playerState)
                EditorTab.OVERLAY -> OverlayToolPanel(playerState)
                EditorTab.CAPTIONS -> TextToolPanel(playerState)
                EditorTab.FILTERS -> FilterToolPanel(playerState)
                EditorTab.ADJUST -> AdjustmentToolPanel(playerState)
                EditorTab.RATIO -> CanvasToolPanel(playerState)
                EditorTab.STICKERS -> StickerToolPanel(playerState)
                EditorTab.CANVAS -> AdjustmentToolPanel(playerState)
                EditorTab.TRIM -> TrimToolPanel(playerState)
                EditorTab.SPEED -> SpeedToolPanel(playerState)
            }
        }
    }
}

@Composable
fun EditToolPanel(playerState: VideoPlayerState) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        Button(
            onClick = {
                playerState.takeSnapshot()
                playerState.seekTo(playerState.currentTimeMs)
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF27272A)),
            shape = RoundedCornerShape(10.dp)
        ) {
            Icon(imageVector = Icons.Default.ContentCut, contentDescription = null, tint = KwaiMagenta)
            Spacer(modifier = Modifier.width(4.dp))
            Text("Split Clip", color = Color.White, fontSize = 12.sp)
        }

        Button(
            onClick = {
                playerState.takeSnapshot()
                playerState.playbackSpeed = if (playerState.playbackSpeed == 1f) 2f else 1f
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF27272A)),
            shape = RoundedCornerShape(10.dp)
        ) {
            Icon(imageVector = Icons.Default.Speed, contentDescription = null, tint = KwaiCyan)
            Spacer(modifier = Modifier.width(4.dp))
            Text("${playerState.playbackSpeed}x Speed", color = Color.White, fontSize = 12.sp)
        }

        Button(
            onClick = {
                playerState.takeSnapshot()
                playerState.textOverlays.clear()
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF27272A)),
            shape = RoundedCornerShape(10.dp)
        ) {
            Icon(imageVector = Icons.Default.Delete, contentDescription = null, tint = Color.Red)
            Spacer(modifier = Modifier.width(4.dp))
            Text("Delete", color = Color.White, fontSize = 12.sp)
        }
    }
}

@Composable
fun OverlayToolPanel(playerState: VideoPlayerState) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Overlay (PIP)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { playerState.takeSnapshot() },
                colors = ButtonDefaults.buttonColors(containerColor = KwaiMagenta),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = null, tint = OnKwaiMagenta)
                Spacer(modifier = Modifier.width(4.dp))
                Text("+ Add Overlay Track", color = OnKwaiMagenta, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun CanvasToolPanel(playerState: VideoPlayerState) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Canvas & Aspect Ratio", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(AspectRatio.entries) { ratio ->
                FilterChip(
                    selected = playerState.aspectRatio == ratio,
                    onClick = {
                        playerState.takeSnapshot()
                        playerState.aspectRatio = ratio
                    },
                    label = { Text(ratio.label) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = KwaiMagenta,
                        selectedLabelColor = Color.White,
                        containerColor = Color(0xFF27272A),
                        labelColor = TextSecondary
                    )
                )
            }
        }
    }
}

@Composable
fun TrimToolPanel(playerState: VideoPlayerState) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Trim Start & End Points", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(
                text = "${formatTimecodeShort(playerState.trimStartMs)} - ${formatTimecodeShort(playerState.trimEndMs)}",
                color = KwaiCyan,
                fontSize = 11.sp
            )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Start:", color = TextSecondary, fontSize = 11.sp, modifier = Modifier.width(40.dp))
            Slider(
                value = playerState.trimStartMs.toFloat(),
                onValueChange = { playerState.updateTrim(it.toLong(), playerState.trimEndMs) },
                valueRange = 0f..(playerState.trimEndMs - 1000f).coerceAtLeast(1f),
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
fun SpeedToolPanel(playerState: VideoPlayerState) {
    val speedOptions = listOf(0.25f, 0.5f, 1.0f, 1.5f, 2.0f, 3.0f, 4.0f)
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Speed (${playerState.playbackSpeed}x)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(speedOptions) { speed ->
                FilterChip(
                    selected = playerState.playbackSpeed == speed,
                    onClick = {
                        playerState.takeSnapshot()
                        playerState.playbackSpeed = speed
                    },
                    label = { Text("${speed}x") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = KwaiMagenta,
                        selectedLabelColor = Color.White,
                        containerColor = Color(0xFF27272A),
                        labelColor = TextSecondary
                    )
                )
            }
        }
    }
}

@Composable
fun FilterToolPanel(playerState: VideoPlayerState) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Aesthetic Filters", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(FilterPreset.entries) { filter ->
                FilterChip(
                    selected = playerState.filterPreset == filter,
                    onClick = {
                        playerState.takeSnapshot()
                        playerState.filterPreset = filter
                    },
                    label = { Text(filter.displayName) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = KwaiMagenta,
                        selectedLabelColor = Color.White,
                        containerColor = Color(0xFF27272A),
                        labelColor = TextSecondary
                    )
                )
            }
        }
    }
}

@Composable
fun AdjustmentToolPanel(playerState: VideoPlayerState) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text("Color & Lighting Adjustments", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Brightness", color = TextSecondary, fontSize = 10.sp, modifier = Modifier.width(65.dp))
            Slider(
                value = playerState.brightness,
                onValueChange = { playerState.brightness = it },
                valueRange = -1f..1f,
                modifier = Modifier.weight(1f)
            )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Warmth", color = TextSecondary, fontSize = 10.sp, modifier = Modifier.width(65.dp))
            Slider(
                value = playerState.warmth,
                onValueChange = { playerState.warmth = it },
                valueRange = -1f..1f,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
fun MagicEffectsToolPanel(playerState: VideoPlayerState) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Magic Visual FX", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(MagicEffect.entries) { effect ->
                FilterChip(
                    selected = playerState.magicEffect == effect,
                    onClick = { playerState.magicEffect = effect },
                    label = { Text(effect.displayName) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = KwaiGold,
                        selectedLabelColor = Color.Black,
                        containerColor = Color(0xFF27272A),
                        labelColor = TextSecondary
                    )
                )
            }
        }
    }
}

@Composable
fun TextToolPanel(playerState: VideoPlayerState) {
    var textInput by remember { mutableStateOf(playerState.textOverlays.firstOrNull()?.text ?: "") }

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Subtitle & Text Layer", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = textInput,
                onValueChange = {
                    textInput = it
                    if (playerState.textOverlays.isEmpty()) {
                        playerState.textOverlays.add(TextOverlay(text = it))
                    } else {
                        val first = playerState.textOverlays.removeAt(0)
                        playerState.textOverlays.add(0, first.copy(text = it))
                    }
                },
                placeholder = { Text("Subtitle text", color = TextMuted) },
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = KwaiMagenta),
                modifier = Modifier.weight(1f)
            )

            Button(
                onClick = {
                    playerState.textOverlays.add(TextOverlay(text = "Subtitle Layer"))
                },
                colors = ButtonDefaults.buttonColors(containerColor = KwaiMagenta)
            ) {
                Text("+ Add", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun StickerToolPanel(playerState: VideoPlayerState) {
    val emojiList = listOf("🔥", "✨", "⚡", "📼", "🎬", "🚀", "🌅", "💯", "❤️", "👑")
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Graphic Stickers", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(emojiList) { emoji ->
                Surface(
                    shape = CircleShape,
                    color = Color(0xFF27272A),
                    modifier = Modifier
                        .size(40.dp)
                        .clickable {
                            playerState.stickerOverlays.add(StickerOverlay(emojiOrIcon = emoji))
                        }
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(emoji, fontSize = 20.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun AudioToolPanel(playerState: VideoPlayerState) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Audio Track", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(SampleData.audioTracks) { track ->
                FilterChip(
                    selected = playerState.selectedAudioTrack?.id == track.id,
                    onClick = { playerState.selectedAudioTrack = track },
                    label = { Text("${track.title} (${track.category})") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = KwaiGold,
                        selectedLabelColor = Color.Black,
                        containerColor = Color(0xFF27272A),
                        labelColor = TextSecondary
                    )
                )
            }
        }
    }
}

@Composable
fun BottomToolTabsBar(
    activeTab: EditorTab,
    onTabSelect: (EditorTab) -> Unit
) {
    Surface(
        color = Color.Black,
        modifier = Modifier.fillMaxWidth()
    ) {
        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(22.dp)
        ) {
            items(
                listOf(
                    EditorTab.EDIT,
                    EditorTab.AUDIO,
                    EditorTab.TEXT,
                    EditorTab.EFFECTS,
                    EditorTab.OVERLAY,
                    EditorTab.CAPTIONS,
                    EditorTab.FILTERS,
                    EditorTab.ADJUST
                )
            ) { tab ->
                val isSelected = activeTab == tab
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onTabSelect(tab) }
                        .testTag("tab_${tab.name.lowercase()}")
                ) {
                    Icon(
                        imageVector = when (tab) {
                            EditorTab.EDIT -> Icons.Default.ContentCut
                            EditorTab.AUDIO -> Icons.Default.Audiotrack
                            EditorTab.TEXT -> Icons.Default.Title
                            EditorTab.EFFECTS -> Icons.Default.AutoAwesome
                            EditorTab.OVERLAY -> Icons.Default.Layers
                            EditorTab.CAPTIONS -> Icons.Default.ClosedCaption
                            EditorTab.FILTERS -> Icons.Default.Palette
                            EditorTab.ADJUST -> Icons.Default.Tune
                            else -> Icons.Default.Tune
                        },
                        contentDescription = tab.label,
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = tab.label,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = Color.White
                    )
                }
            }
        }
    }
}

private fun formatTimecodeShort(ms: Long): String {
    val totalSeconds = ms / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return String.format(Locale.US, "%02d:%02d", minutes, seconds)
}
