package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.ExportFps
import com.example.data.ExportQuality
import com.example.data.ExportResolution
import com.example.ui.theme.*
import com.example.viewmodel.EditorViewModel

@Composable
fun ExportConfigurationDialog(
    viewModel: EditorViewModel,
    onDismiss: () -> Unit,
    onConfirmExport: () -> Unit
) {
    var selectedResolution by remember { mutableStateOf(viewModel.exportResolution) }
    var selectedFps by remember { mutableStateOf(viewModel.exportFps) }
    var selectedQuality by remember { mutableStateOf(viewModel.exportQuality) }

    // Estimate file size based on resolution, duration, and bitrate
    val durationSec = (viewModel.playerState.totalDurationMs / 1000f).coerceAtLeast(1f)
    val estimatedMb = ((selectedQuality.bitrateMbps * durationSec / 8f) * (selectedFps.fps / 30f)).toInt().coerceAtLeast(5)

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = KwaiPanelSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, KwaiBorder),
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight()
                .testTag("export_configuration_dialog")
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = KwaiMagenta.copy(alpha = 0.2f),
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.HighQuality,
                                    contentDescription = null,
                                    tint = KwaiMagenta,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Column {
                            Text(
                                text = "Export Configuration",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            )
                            Text(
                                text = "Choose resolution & frame rate",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("close_export_config_dialog")
                    ) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }

                HorizontalDivider(color = KwaiBorder)

                // 1. Export Quality Selection (1080p vs 4K)
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Select Export Quality",
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                    
                    val qualityOptions = listOf(
                        Triple(ExportResolution.RES_1080P, "1080p Full HD", "1080 x 1920 • High Bitrate • Fast (~4s)"),
                        Triple(ExportResolution.RES_4K, "4K Ultra HD", "2160 x 3840 • Ultra Crisp • HEVC (~8s)"),
                        Triple(ExportResolution.RES_720P, "720p HD", "720 x 1280 • Compact File • Standard (~2s)")
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        qualityOptions.forEach { (res, title, desc) ->
                            val isSelected = selectedResolution == res
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = if (isSelected) KwaiMagenta.copy(alpha = 0.18f) else KwaiCardSurface,
                                border = androidx.compose.foundation.BorderStroke(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) KwaiMagenta else KwaiBorder
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedResolution = res }
                                    .testTag("select_quality_${res.name.lowercase()}")
                            ) {
                                Row(
                                    modifier = Modifier
                                        .padding(horizontal = 14.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        RadioButton(
                                            selected = isSelected,
                                            onClick = { selectedResolution = res },
                                            colors = RadioButtonDefaults.colors(
                                                selectedColor = KwaiMagenta,
                                                unselectedColor = TextMuted
                                            )
                                        )
                                        Column {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Text(
                                                    text = title,
                                                    color = Color.White,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 15.sp
                                                )
                                                if (res == ExportResolution.RES_1080P) {
                                                    Surface(
                                                        shape = RoundedCornerShape(4.dp),
                                                        color = KwaiCyan.copy(alpha = 0.25f)
                                                    ) {
                                                        Text(
                                                            text = "POPULAR",
                                                            color = KwaiCyan,
                                                            fontSize = 9.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }
                                            }
                                            Text(
                                                text = desc,
                                                color = TextSecondary,
                                                fontSize = 11.sp
                                            )
                                        }
                                    }

                                    if (res == ExportResolution.RES_4K) {
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = KwaiGold
                                        ) {
                                            Text(
                                                text = "ULTRA 4K",
                                                color = Color.Black,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Black,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // 2. Frame Rate (FPS)
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Frame Rate",
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        ExportFps.entries.forEach { fps ->
                            val isSelected = selectedFps == fps
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) KwaiCyan.copy(alpha = 0.2f) else KwaiCardSurface,
                                border = androidx.compose.foundation.BorderStroke(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) KwaiCyan else KwaiBorder
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { selectedFps = fps }
                                    .testTag("select_fps_${fps.fps}")
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.padding(vertical = 10.dp)
                                ) {
                                    Text(
                                        text = "${fps.fps} FPS",
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) KwaiCyan else Color.White,
                                        fontSize = 15.sp
                                    )
                                    Text(
                                        text = if (fps.fps == 60) "Ultra Smooth" else "Standard",
                                        color = TextSecondary,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }
                }

                // 3. Bitrate / Quality
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Quality & Bitrate",
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        ExportQuality.entries.forEach { quality ->
                            val isSelected = selectedQuality == quality
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedQuality = quality },
                                label = { Text(quality.label) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = KwaiGold,
                                    selectedLabelColor = Color.Black,
                                    containerColor = KwaiCardSurface,
                                    labelColor = TextSecondary
                                ),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                // File Size Info Card
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = KwaiCardSurface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = KwaiCyan)
                        Column {
                            Text(
                                text = "Estimated File Size: ~$estimatedMb MB",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                            Text(
                                text = "H.264 / AAC High Profile Hardware Encoder",
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                // Action Buttons
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Button(
                        onClick = {
                            viewModel.exportResolution = selectedResolution
                            viewModel.exportFps = selectedFps
                            viewModel.exportQuality = selectedQuality
                            onConfirmExport()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = KwaiGold),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("export_to_gallery_dialog_button")
                    ) {
                        Icon(imageVector = Icons.Default.Download, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Export ${selectedResolution.label.split(" ").first()} & Save to Gallery",
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedButton(
                            onClick = onDismiss,
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Cancel")
                        }

                        Button(
                            onClick = {
                                viewModel.exportResolution = selectedResolution
                                viewModel.exportFps = selectedFps
                                viewModel.exportQuality = selectedQuality
                                onConfirmExport()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = KwaiMagenta),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .weight(1.3f)
                                .testTag("confirm_initialize_rendering_button")
                        ) {
                            Icon(imageVector = Icons.Default.RocketLaunch, contentDescription = null, tint = OnKwaiMagenta, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Start ${selectedResolution.label.split(" ").first()} Render",
                                fontWeight = FontWeight.Bold,
                                color = OnKwaiMagenta
                            )
                        }
                    }
                }
            }
        }
    }
}
