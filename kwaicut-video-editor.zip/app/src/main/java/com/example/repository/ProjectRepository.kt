package com.example.repository

import com.example.data.db.ProjectDao
import com.example.data.db.ProjectEntity
import kotlinx.coroutines.flow.Flow

class ProjectRepository(private val dao: ProjectDao) {
    val allProjects: Flow<List<ProjectEntity>> = dao.getAllProjects()
    val exportedProjects: Flow<List<ProjectEntity>> = dao.getExportedProjects()

    suspend fun getProjectById(id: String): ProjectEntity? = dao.getProjectById(id)

    suspend fun saveProject(project: ProjectEntity) {
        dao.insertOrUpdate(project)
    }

    suspend fun deleteProject(id: String) {
        dao.deleteById(id)
    }
}
