package com.example.viewmodel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import com.example.data.db.KwaiCutDatabase
import com.example.data.db.ProjectEntity
import com.example.repository.ProjectRepository
import com.example.video.VideoPlayerState
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

class EditorViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: ProjectRepository

    val playerState = VideoPlayerState()

    var activeProjectId by mutableStateOf(UUID.randomUUID().toString())
    var projectTitle by mutableStateOf("My Viral Edit")
    var activeTab by mutableStateOf(EditorTab.CANVAS) // Editor panel tab

    // Auto-Save State (Room DB)
    var isAutoSaving by mutableStateOf(false)
    var lastAutoSaveTime by mutableStateOf<Long?>(null)

    // Detailed Rendering & Export State
    var isExporting by mutableStateOf(false)
    var exportProgress by mutableStateOf(0f)
    var exportResolution by mutableStateOf(ExportResolution.RES_1080P)
    var exportFps by mutableStateOf(ExportFps.FPS_60)
    var exportQuality by mutableStateOf(ExportQuality.HIGH)
    var exportedSuccessPath by mutableStateOf<String?>(null)
    var renderingStageText by mutableStateOf("Initializing GPU Render Pipeline...")
    var renderingStageIndex by mutableStateOf(1)
    var totalRenderingStages by mutableStateOf(6)
    var estimatedTimeRemainingSec by mutableStateOf(5)

    val savedProjects: StateFlow<List<ProjectEntity>>

    init {
        val dao = KwaiCutDatabase.getDatabase(application).projectDao()
        repository = ProjectRepository(dao)
        savedProjects = repository.allProjects.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )
        
        // Start 30-second Room database auto-save timer
        startAutoSaveLoop()
    }

    private fun startAutoSaveLoop() {
        viewModelScope.launch {
            while (true) {
                delay(30_000L) // Persist every 30 seconds
                performAutoSave()
            }
        }
    }

    private suspend fun performAutoSave() {
        isAutoSaving = true
        val entity = ProjectEntity(
            id = activeProjectId,
            title = projectTitle,
            durationMs = playerState.totalDurationMs,
            aspectRatioName = playerState.aspectRatio.name,
            filterPresetName = playerState.filterPreset.name,
            magicEffectName = playerState.magicEffect.name,
            playbackSpeed = playerState.playbackSpeed,
            brightness = playerState.brightness,
            contrast = playerState.contrast,
            saturation = playerState.saturation,
            warmth = playerState.warmth,
            textOverlayText = playerState.textOverlays.firstOrNull()?.text ?: "",
            stickerOverlayEmoji = playerState.stickerOverlays.firstOrNull()?.emojiOrIcon ?: "🔥",
            audioTrackName = playerState.selectedAudioTrack?.title ?: "Default Audio",
            isExported = false,
            lastModifiedMs = System.currentTimeMillis()
        )
        repository.saveProject(entity)
        lastAutoSaveTime = System.currentTimeMillis()
        delay(600L)
        isAutoSaving = false
    }

    fun createNewProject() {
        activeProjectId = UUID.randomUUID().toString()
        projectTitle = "Project ${System.currentTimeMillis() % 1000}"
        playerState.currentTimeMs = 0
        playerState.filterPreset = FilterPreset.NORMAL
        playerState.magicEffect = MagicEffect.NONE
        playerState.brightness = 0f
        playerState.contrast = 1f
        playerState.saturation = 1f
        playerState.warmth = 0f
        playerState.textOverlays.clear()
        playerState.textOverlays.add(TextOverlay(text = "KwaiCut Video Editor", fontSizeSp = 22))
        playerState.stickerOverlays.clear()
        playerState.stickerOverlays.add(StickerOverlay(emojiOrIcon = "🔥", label = "Trending"))
        saveDraft()
    }

    fun applyTemplate(template: VideoTemplate) {
        activeProjectId = UUID.randomUUID().toString()
        projectTitle = template.title
        playerState.totalDurationMs = template.durationMs
        playerState.trimStartMs = 0
        playerState.trimEndMs = template.durationMs
        playerState.currentTimeMs = 0
        playerState.aspectRatio = template.aspectRatio
        playerState.filterPreset = template.filterPreset
        playerState.magicEffect = template.magicEffect
        playerState.textOverlays.clear()
        playerState.textOverlays.add(TextOverlay(text = template.textSample, fontSizeSp = 24))
        playerState.stickerOverlays.clear()
        playerState.stickerOverlays.add(StickerOverlay(emojiOrIcon = template.stickerSample, label = "Template"))
        saveDraft()
    }

    fun loadProject(entity: ProjectEntity) {
        activeProjectId = entity.id
        projectTitle = entity.title
        playerState.totalDurationMs = entity.durationMs
        playerState.playbackSpeed = entity.playbackSpeed
        playerState.filterPreset = try { FilterPreset.valueOf(entity.filterPresetName) } catch (e: Exception) { FilterPreset.NORMAL }
        playerState.magicEffect = try { MagicEffect.valueOf(entity.magicEffectName) } catch (e: Exception) { MagicEffect.NONE }
        playerState.brightness = entity.brightness
        playerState.contrast = entity.contrast
        playerState.saturation = entity.saturation
        playerState.warmth = entity.warmth
        playerState.textOverlays.clear()
        playerState.textOverlays.add(TextOverlay(text = entity.textOverlayText, fontSizeSp = 22))
        playerState.stickerOverlays.clear()
        playerState.stickerOverlays.add(StickerOverlay(emojiOrIcon = entity.stickerOverlayEmoji, label = "Draft"))
    }

    fun saveDraft() {
        viewModelScope.launch {
            val entity = ProjectEntity(
                id = activeProjectId,
                title = projectTitle,
                durationMs = playerState.totalDurationMs,
                aspectRatioName = playerState.aspectRatio.name,
                filterPresetName = playerState.filterPreset.name,
                magicEffectName = playerState.magicEffect.name,
                playbackSpeed = playerState.playbackSpeed,
                brightness = playerState.brightness,
                contrast = playerState.contrast,
                saturation = playerState.saturation,
                warmth = playerState.warmth,
                textOverlayText = playerState.textOverlays.firstOrNull()?.text ?: "",
                stickerOverlayEmoji = playerState.stickerOverlays.firstOrNull()?.emojiOrIcon ?: "🔥",
                audioTrackName = playerState.selectedAudioTrack?.title ?: "Default Audio",
                isExported = false,
                lastModifiedMs = System.currentTimeMillis()
            )
            repository.saveProject(entity)
        }
    }

    fun startExport(onComplete: () -> Unit) {
        if (isExporting) return
        isExporting = true
        exportProgress = 0f
        exportedSuccessPath = null

        val is4K = exportResolution == ExportResolution.RES_4K
        val stages = if (is4K) {
            listOf(
                "Initializing 4K GPU Render Pipeline...",
                "Decoding High Bitrate 4K Source Clips...",
                "Applying ${playerState.filterPreset.displayName} Filters & Color LUTs...",
                "Rendering FX Overlays & Keyframe Animations...",
                "Mixing Multi-track Audio & Captions...",
                "Encoding 4K Ultra HD (3840x2160) HEVC Video Stream..."
            )
        } else {
            listOf(
                "Initializing Render Pipeline...",
                "Decoding Source Video Frames...",
                "Applying Color Filters & Effects...",
                "Blending Text Overlays & Audio Tracks...",
                "Encoding ${exportResolution.label} Video Stream...",
                "Finalizing Output Container & Metadata..."
            )
        }

        totalRenderingStages = stages.size

        viewModelScope.launch {
            val stepDelayMs = if (is4K) 45L else 25L
            val totalSteps = 100

            for (step in 1..totalSteps) {
                delay(stepDelayMs)
                exportProgress = step / 100f

                val stageIdx = ((step - 1) * stages.size / totalSteps).coerceIn(0, stages.size - 1)
                renderingStageIndex = stageIdx + 1
                renderingStageText = stages[stageIdx]

                val remainingSteps = totalSteps - step
                estimatedTimeRemainingSec = ((remainingSteps * stepDelayMs) / 1000L).toInt().coerceAtLeast(1)
            }

            isExporting = false
            val mockPath = "/storage/emulated/0/Movies/KwaiCut_${if (is4K) "4K_" else ""}${System.currentTimeMillis()}.mp4"
            exportedSuccessPath = mockPath

            // Save to Room database as exported video
            val entity = ProjectEntity(
                id = activeProjectId,
                title = projectTitle,
                durationMs = playerState.totalDurationMs,
                aspectRatioName = playerState.aspectRatio.name,
                filterPresetName = playerState.filterPreset.name,
                magicEffectName = playerState.magicEffect.name,
                playbackSpeed = playerState.playbackSpeed,
                brightness = playerState.brightness,
                contrast = playerState.contrast,
                saturation = playerState.saturation,
                warmth = playerState.warmth,
                textOverlayText = playerState.textOverlays.firstOrNull()?.text ?: "",
                stickerOverlayEmoji = playerState.stickerOverlays.firstOrNull()?.emojiOrIcon ?: "🔥",
                audioTrackName = playerState.selectedAudioTrack?.title ?: "Default Audio",
                isExported = true,
                exportedResolution = exportResolution.label,
                exportedFilePath = mockPath,
                lastModifiedMs = System.currentTimeMillis()
            )
            repository.saveProject(entity)
            lastAutoSaveTime = System.currentTimeMillis()
            onComplete()
        }
    }

    fun deleteProject(id: String) {
        viewModelScope.launch {
            repository.deleteProject(id)
        }
    }
}

enum class EditorTab(val label: String, val iconName: String) {
    EDIT("Edit", "content_cut"),
    AUDIO("Audio", "audiotrack"),
    TEXT("Text", "title"),
    EFFECTS("Effects", "auto_awesome"),
    OVERLAY("Overlay", "layers"),
    CAPTIONS("Captions", "closed_caption"),
    FILTERS("Filters", "palette"),
    ADJUST("Adjust", "tune"),
    RATIO("Ratio", "aspect_ratio"),
    STICKERS("Sticker", "sentiment_satisfied"),
    CANVAS("Canvas", "tune"),
    TRIM("Trim", "straighten"),
    SPEED("Speed", "speed")
}
