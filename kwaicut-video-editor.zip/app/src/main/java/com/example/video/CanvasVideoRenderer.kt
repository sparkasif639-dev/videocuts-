package com.example.video

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin

data class TimelineSnapshot(
    val trimStartMs: Long,
    val trimEndMs: Long,
    val totalDurationMs: Long,
    val filterPreset: FilterPreset,
    val magicEffect: MagicEffect,
    val brightness: Float,
    val contrast: Float,
    val saturation: Float,
    val warmth: Float,
    val playbackSpeed: Float,
    val aspectRatio: AspectRatio,
    val isAudioMuted: Boolean,
    val coverImageName: String,
    val selectedAudioTrack: AudioTrack?,
    val textOverlays: List<TextOverlay>,
    val stickerOverlays: List<StickerOverlay>
)

class VideoPlayerState(
    initialDurationMs: Long = 12000L
) {
    var isPlaying by mutableStateOf(false)
    var videoUriString by mutableStateOf<String?>(null)
    var currentTimeMs by mutableStateOf(0L)
    var totalDurationMs by mutableStateOf(initialDurationMs)
    var trimStartMs by mutableStateOf(0L)
    var trimEndMs by mutableStateOf(initialDurationMs)
    var playbackSpeed by mutableFloatStateOf(1.0f)
    var aspectRatio by mutableStateOf(AspectRatio.RATIO_9_16)
    var isLooping by mutableStateOf(true)

    // Filter & Adjustments
    var filterPreset by mutableStateOf(FilterPreset.NORMAL)
    var magicEffect by mutableStateOf(MagicEffect.NONE)
    var brightness by mutableFloatStateOf(0f) // -1.0 to 1.0
    var contrast by mutableFloatStateOf(1f)   // 0.5 to 2.0
    var saturation by mutableFloatStateOf(1f) // 0.0 to 2.0
    var warmth by mutableFloatStateOf(0f)     // -1.0 to 1.0

    // Overlays
    var textOverlays = mutableStateListOf<TextOverlay>(
        TextOverlay(text = "KwaiCut Video Editor ✨", fontSizeSp = 24)
    )
    var stickerOverlays = mutableStateListOf<StickerOverlay>(
        StickerOverlay(emojiOrIcon = "🔥", label = "Trending")
    )

    // Audio & State Flags
    var selectedAudioTrack by mutableStateOf<AudioTrack?>(SampleData.audioTracks.first())
    var musicVolume by mutableFloatStateOf(0.8f)
    var originalVideoVolume by mutableFloatStateOf(1.0f)
    var isAudioMuted by mutableStateOf(false)
    var isKeyframeAdded by mutableStateOf(false)
    var coverImageName by mutableStateOf("Cover")

    // Undo / Redo State Manager
    private val undoStack = mutableListOf<TimelineSnapshot>()
    private val redoStack = mutableListOf<TimelineSnapshot>()
    var canUndo by mutableStateOf(false)
    var canRedo by mutableStateOf(false)
    var actionNotice by mutableStateOf<String?>(null)

    fun takeSnapshot() {
        val snapshot = TimelineSnapshot(
            trimStartMs = trimStartMs,
            trimEndMs = trimEndMs,
            totalDurationMs = totalDurationMs,
            filterPreset = filterPreset,
            magicEffect = magicEffect,
            brightness = brightness,
            contrast = contrast,
            saturation = saturation,
            warmth = warmth,
            playbackSpeed = playbackSpeed,
            aspectRatio = aspectRatio,
            isAudioMuted = isAudioMuted,
            coverImageName = coverImageName,
            selectedAudioTrack = selectedAudioTrack,
            textOverlays = textOverlays.map { it.copy() },
            stickerOverlays = stickerOverlays.map { it.copy() }
        )
        undoStack.add(snapshot)
        if (undoStack.size > 30) {
            undoStack.removeAt(0)
        }
        redoStack.clear()
        updateUndoRedoStates()
    }

    private fun updateUndoRedoStates() {
        canUndo = undoStack.isNotEmpty()
        canRedo = redoStack.isNotEmpty()
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        val currentSnapshot = createCurrentSnapshot()
        redoStack.add(currentSnapshot)

        val last = undoStack.removeAt(undoStack.lastIndex)
        applySnapshot(last)
        updateUndoRedoStates()
        actionNotice = "Undo: Reverted timeline change"
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        val currentSnapshot = createCurrentSnapshot()
        undoStack.add(currentSnapshot)

        val next = redoStack.removeAt(redoStack.lastIndex)
        applySnapshot(next)
        updateUndoRedoStates()
        actionNotice = "Redo: Re-applied timeline change"
    }

    private fun createCurrentSnapshot(): TimelineSnapshot {
        return TimelineSnapshot(
            trimStartMs = trimStartMs,
            trimEndMs = trimEndMs,
            totalDurationMs = totalDurationMs,
            filterPreset = filterPreset,
            magicEffect = magicEffect,
            brightness = brightness,
            contrast = contrast,
            saturation = saturation,
            warmth = warmth,
            playbackSpeed = playbackSpeed,
            aspectRatio = aspectRatio,
            isAudioMuted = isAudioMuted,
            coverImageName = coverImageName,
            selectedAudioTrack = selectedAudioTrack,
            textOverlays = textOverlays.map { it.copy() },
            stickerOverlays = stickerOverlays.map { it.copy() }
        )
    }

    private fun applySnapshot(snapshot: TimelineSnapshot) {
        trimStartMs = snapshot.trimStartMs
        trimEndMs = snapshot.trimEndMs
        totalDurationMs = snapshot.totalDurationMs
        filterPreset = snapshot.filterPreset
        magicEffect = snapshot.magicEffect
        brightness = snapshot.brightness
        contrast = snapshot.contrast
        saturation = snapshot.saturation
        warmth = snapshot.warmth
        playbackSpeed = snapshot.playbackSpeed
        aspectRatio = snapshot.aspectRatio
        isAudioMuted = snapshot.isAudioMuted
        coverImageName = snapshot.coverImageName
        selectedAudioTrack = snapshot.selectedAudioTrack

        textOverlays.clear()
        textOverlays.addAll(snapshot.textOverlays)

        stickerOverlays.clear()
        stickerOverlays.addAll(snapshot.stickerOverlays)
    }

    fun seekTo(timeMs: Long) {
        currentTimeMs = timeMs.coerceIn(trimStartMs, trimEndMs)
    }

    fun togglePlay() {
        isPlaying = !isPlaying
    }

    fun updateTrim(startMs: Long, endMs: Long) {
        takeSnapshot()
        trimStartMs = startMs.coerceIn(0L, totalDurationMs)
        trimEndMs = endMs.coerceIn(trimStartMs, totalDurationMs)
        if (currentTimeMs < trimStartMs || currentTimeMs > trimEndMs) {
            currentTimeMs = trimStartMs
        }
    }
}

@Composable
fun CanvasVideoPlayer(
    playerState: VideoPlayerState,
    modifier: Modifier = Modifier,
    showControls: Boolean = true
) {
    val coroutineScope = rememberCoroutineScope()

    // Playback loop ticker
    LaunchedEffect(playerState.isPlaying, playerState.playbackSpeed, playerState.currentTimeMs) {
        if (playerState.isPlaying) {
            val stepMs = (33 * playerState.playbackSpeed).toLong()
            while (playerState.isPlaying) {
                delay(33)
                val nextTime = playerState.currentTimeMs + stepMs
                if (nextTime >= playerState.trimEndMs) {
                    if (playerState.isLooping) {
                        playerState.currentTimeMs = playerState.trimStartMs
                    } else {
                        playerState.currentTimeMs = playerState.trimEndMs
                        playerState.isPlaying = false
                    }
                } else {
                    playerState.currentTimeMs = nextTime
                }
            }
        }
    }

    val textMeasurer = rememberTextMeasurer()

    Box(
        modifier = modifier
            .background(Color.Black)
            .clickable { playerState.togglePlay() },
        contentAlignment = Alignment.Center
    ) {
        // Calculate Canvas dimension for aspect ratio
        Box(
            modifier = Modifier
                .aspectRatio(playerState.aspectRatio.ratio)
                .fillMaxSize()
                .clip(RoundedCornerShape(8.dp))
                .border(1.dp, Color(0xFF2B2F3A), RoundedCornerShape(8.dp))
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val width = size.width
                val height = size.height
                val timeSec = playerState.currentTimeMs / 1000f

                // 1. Base Video Frame Synthesizer
                drawVideoBaseFrame(width, height, timeSec, playerState.filterPreset)

                // 2. Color Adjustments Matrix Overlay
                drawColorAdjustments(width, height, playerState.brightness, playerState.contrast, playerState.saturation, playerState.warmth)

                // 3. Magic Visual Effects
                drawMagicEffects(width, height, timeSec, playerState.magicEffect)

                // 4. Draw Sticker Overlays
                playerState.stickerOverlays.forEach { sticker ->
                    if (playerState.currentTimeMs in sticker.startMs..sticker.endMs) {
                        drawSticker(width, height, sticker, textMeasurer)
                    }
                }

                // 5. Draw Animated Text Overlays
                playerState.textOverlays.forEach { textOverlay ->
                    if (playerState.currentTimeMs in textOverlay.startMs..textOverlay.endMs) {
                        drawAnimatedText(width, height, timeSec, textOverlay, textMeasurer)
                    }
                }
            }

            // Play/Pause Overlay indicator when paused
            if (!playerState.isPlaying && showControls) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.35f)),
                    contentAlignment = Alignment.Center
                ) {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = Color(0xFFFF007F).copy(alpha = 0.9f),
                        modifier = Modifier.size(64.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Play",
                                tint = Color.White,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun DrawScope.drawVideoBaseFrame(
    width: Float,
    height: Float,
    timeSec: Float,
    preset: FilterPreset
) {
    // Dynamic color gradient based on filter preset
    val (primaryColor, secondaryColor, accentColor) = when (preset) {
        FilterPreset.NORMAL -> Triple(Color(0xFF1E293B), Color(0xFF334155), Color(0xFF00F2FE))
        FilterPreset.CYBERPUNK -> Triple(Color(0xFF2A0845), Color(0xFF6441A5), Color(0xFFFF007F))
        FilterPreset.VINTAGE_VHS -> Triple(Color(0xFF4A2E12), Color(0xFF8B5A2B), Color(0xFFF39C12))
        FilterPreset.CINEMATIC_GOLD -> Triple(Color(0xFF1C1A17), Color(0xFF3D3222), Color(0xFFFFD700))
        FilterPreset.SOFT_PINK -> Triple(Color(0xFF3B1E2B), Color(0xFF8E4485), Color(0xFFFFB6C1))
        FilterPreset.NEO_NOIR -> Triple(Color(0xFF050505), Color(0xFF1F1F1F), Color(0xFFE0E0E0))
        FilterPreset.RETRO_80S -> Triple(Color(0xFF320040), Color(0xFF800080), Color(0xFF00FFFF))
        FilterPreset.DRAMA_DARK -> Triple(Color(0xFF0F172A), Color(0xFF1E293B), Color(0xFFEF4444))
        FilterPreset.WARM_SUMMER -> Triple(Color(0xFF4C2A00), Color(0xFF995200), Color(0xFFF59E0B))
        FilterPreset.GLITCH_WAVE -> Triple(Color(0xFF110022), Color(0xFF330066), Color(0xFF00FFCC))
        FilterPreset.VIVID_POP -> Triple(Color(0xFF990000), Color(0xFFCC0066), Color(0xFFFFFF00))
        FilterPreset.BW_CLASSIC -> Triple(Color(0xFF101010), Color(0xFF404040), Color(0xFFCCCCCC))
    }

    // Animated background gradient shifting with video playback time
    val shiftX = sin(timeSec * 1.5f) * width * 0.3f
    val shiftY = cos(timeSec * 1.2f) * height * 0.3f

    drawRect(
        brush = Brush.radialGradient(
            colors = listOf(accentColor, secondaryColor, primaryColor),
            center = Offset(width / 2 + shiftX, height / 2 + shiftY),
            radius = height * 0.85f
        ),
        size = Size(width, height)
    )

    // Draw video horizon wave grid lines
    val gridLines = 8
    val waveOffset = (timeSec * 120f) % (height / gridLines)
    for (i in 0..gridLines + 1) {
        val y = i * (height / gridLines) - waveOffset
        if (y in 0f..height) {
            drawLine(
                color = accentColor.copy(alpha = 0.25f),
                start = Offset(0f, y),
                end = Offset(width, y),
                strokeWidth = 2f
            )
        }
    }

    // Draw rotating geometric sun / video frame core element
    rotate(degrees = timeSec * 25f, pivot = Offset(width / 2f, height * 0.45f)) {
        val radius = width * 0.22f
        drawCircle(
            brush = Brush.linearGradient(
                colors = listOf(accentColor.copy(alpha = 0.8f), primaryColor.copy(alpha = 0.3f))
            ),
            radius = radius,
            center = Offset(width / 2f, height * 0.45f)
        )
        drawCircle(
            color = Color.White.copy(alpha = 0.6f),
            radius = radius * 0.85f,
            center = Offset(width / 2f, height * 0.45f),
            style = Stroke(width = 4f)
        )
    }
}

private fun DrawScope.drawColorAdjustments(
    width: Float,
    height: Float,
    brightness: Float,
    contrast: Float,
    saturation: Float,
    warmth: Float
) {
    // Brightness overlay
    if (brightness > 0) {
        drawRect(color = Color.White.copy(alpha = (brightness * 0.3f).coerceIn(0f, 0.4f)), size = Size(width, height))
    } else if (brightness < 0) {
        drawRect(color = Color.Black.copy(alpha = (-brightness * 0.4f).coerceIn(0f, 0.6f)), size = Size(width, height))
    }

    // Warmth overlay
    if (warmth > 0) {
        drawRect(color = Color(0xFFFF9900).copy(alpha = (warmth * 0.25f).coerceIn(0f, 0.3f)), size = Size(width, height))
    } else if (warmth < 0) {
        drawRect(color = Color(0xFF0099FF).copy(alpha = (-warmth * 0.25f).coerceIn(0f, 0.3f)), size = Size(width, height))
    }
}

private fun DrawScope.drawMagicEffects(
    width: Float,
    height: Float,
    timeSec: Float,
    effect: MagicEffect
) {
    when (effect) {
        MagicEffect.NONE -> {}
        MagicEffect.NEON_GLOW -> {
            val pulse = (sin(timeSec * 4f) * 0.5f + 0.5f) * 0.4f + 0.2f
            drawRect(
                brush = Brush.radialGradient(
                    colors = listOf(Color.Transparent, Color(0xFF00F2FE).copy(alpha = pulse)),
                    center = Offset(width / 2, height / 2),
                    radius = height * 0.7f
                )
            )
        }
        MagicEffect.LIGHT_LEAKS -> {
            val leakX = (sin(timeSec * 0.8f) * 0.4f + 0.5f) * width
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFFFF9900).copy(alpha = 0.5f), Color.Transparent),
                    center = Offset(leakX, height * 0.2f),
                    radius = width * 0.7f
                )
            )
        }
        MagicEffect.FILM_GRAIN -> {
            // Simulated grain dust dots
            val dotCount = 40
            for (i in 0 until dotCount) {
                val px = ((i * 137.5f + timeSec * 500f) % width)
                val py = ((i * 291.3f + timeSec * 300f) % height)
                drawCircle(color = Color.White.copy(alpha = 0.25f), radius = 2f, center = Offset(px, py))
            }
        }
        MagicEffect.GLITCH_FX -> {
            val glitchActive = (timeSec * 10).toInt() % 4 == 0
            if (glitchActive) {
                val glitchY = (timeSec * 700f) % height
                drawRect(
                    color = Color(0xFFFF007F).copy(alpha = 0.4f),
                    topLeft = Offset(0f, glitchY),
                    size = Size(width, 24f)
                )
                drawRect(
                    color = Color(0xFF00F2FE).copy(alpha = 0.4f),
                    topLeft = Offset(12f, (glitchY + 30f) % height),
                    size = Size(width - 12f, 16f)
                )
            }
        }
        MagicEffect.BOKEH_STARS -> {
            for (i in 0..12) {
                val starX = (i * 80f + sin(timeSec + i) * 30f) % width
                val starY = (i * 120f + cos(timeSec * 1.5f + i) * 40f) % height
                val alpha = (sin(timeSec * 3f + i) * 0.5f + 0.5f) * 0.6f
                drawCircle(color = Color(0xFFFFD700).copy(alpha = alpha), radius = 8f + i % 6, center = Offset(starX, starY))
            }
        }
        MagicEffect.HEART_PARTICLES -> {
            for (i in 0..8) {
                val hX = (width * 0.2f) + (i * 70f + sin(timeSec * 2f + i) * 20f) % (width * 0.6f)
                val hY = height - ((timeSec * 150f + i * 100f) % height)
                drawCircle(color = Color(0xFFFF007F).copy(alpha = 0.7f), radius = 12f, center = Offset(hX, hY))
            }
        }
        MagicEffect.RGB_SPLIT -> {
            val splitOffset = sin(timeSec * 8f) * 10f
            drawRect(
                color = Color.Red.copy(alpha = 0.15f),
                topLeft = Offset(splitOffset, 0f),
                size = Size(width, height)
            )
            drawRect(
                color = Color.Cyan.copy(alpha = 0.15f),
                topLeft = Offset(-splitOffset, 0f),
                size = Size(width, height)
            )
        }
        MagicEffect.ZOOM_BURST -> {
            val zoomRadius = (timeSec * 400f) % (width * 0.8f)
            drawCircle(
                color = Color.White.copy(alpha = 0.2f),
                radius = zoomRadius,
                center = Offset(width / 2f, height / 2f),
                style = Stroke(width = 6f)
            )
        }
    }
}

private fun DrawScope.drawSticker(
    width: Float,
    height: Float,
    sticker: StickerOverlay,
    textMeasurer: TextMeasurer
) {
    val x = width * sticker.xPosRatio
    val y = height * sticker.yPosRatio

    val textLayoutResult = textMeasurer.measure(
        text = AnnotatedString(sticker.emojiOrIcon),
        style = TextStyle(fontSize = (28 * sticker.scale).sp)
    )

    drawCircle(
        color = Color.Black.copy(alpha = 0.4f),
        radius = 24f * sticker.scale,
        center = Offset(x, y)
    )

    drawText(
        textLayoutResult = textLayoutResult,
        topLeft = Offset(x - textLayoutResult.size.width / 2f, y - textLayoutResult.size.height / 2f)
    )
}

private fun DrawScope.drawAnimatedText(
    width: Float,
    height: Float,
    timeSec: Float,
    overlay: TextOverlay,
    textMeasurer: TextMeasurer
) {
    val alpha = when (overlay.animStyle) {
        TextAnimStyle.FADE_IN -> ((timeSec - overlay.startMs / 1000f) * 2f).coerceIn(0f, 1f)
        TextAnimStyle.NONE -> 1f
        else -> 1f
    }

    val yOffsetAnim = when (overlay.animStyle) {
        TextAnimStyle.SLIDE_UP -> (1f - ((timeSec - overlay.startMs / 1000f) * 2f).coerceIn(0f, 1f)) * 40f
        TextAnimStyle.BOUNCE -> (sin(timeSec * 6f) * 10f)
        else -> 0f
    }

    val color = try {
        Color(android.graphics.Color.parseColor(overlay.colorHex)).copy(alpha = alpha)
    } catch (e: Exception) {
        Color.White.copy(alpha = alpha)
    }

    val textStyle = TextStyle(
        color = color,
        fontSize = overlay.fontSizeSp.sp,
        fontWeight = FontWeight.Bold,
        shadow = Shadow(color = Color.Black, offset = Offset(2f, 2f), blurRadius = 4f)
    )

    val textLayoutResult = textMeasurer.measure(
        text = AnnotatedString(overlay.text),
        style = textStyle
    )

    val centerX = width * overlay.xPosRatio
    val centerY = height * overlay.yPosRatio + yOffsetAnim

    // Background pill
    val bgPaddingHorizontal = 16f
    val bgPaddingVertical = 8f
    val bgWidth = textLayoutResult.size.width + bgPaddingHorizontal * 2
    val bgHeight = textLayoutResult.size.height + bgPaddingVertical * 2

    val bgRectX = centerX - bgWidth / 2f
    val bgRectY = centerY - bgHeight / 2f

    drawRoundRect(
        color = Color.Black.copy(alpha = 0.5f * alpha),
        topLeft = Offset(bgRectX, bgRectY),
        size = Size(bgWidth, bgHeight),
        cornerRadius = CornerRadius(16f, 16f)
    )

    drawText(
        textLayoutResult = textLayoutResult,
        topLeft = Offset(centerX - textLayoutResult.size.width / 2f, centerY - textLayoutResult.size.height / 2f)
    )
}
