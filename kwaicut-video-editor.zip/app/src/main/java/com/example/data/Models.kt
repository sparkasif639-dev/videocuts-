package com.example.data

import androidx.annotation.DrawableRes

enum class AspectRatio(val label: String, val ratio: Float, val iconName: String) {
    RATIO_9_16("9:16 (TikTok/Reels)", 9f / 16f, "Vertical"),
    RATIO_1_1("1:1 (Square)", 1f / 1f, "Square"),
    RATIO_16_9("16:9 (YouTube)", 16f / 9f, "Horizontal"),
    RATIO_4_5("4:5 (Insta Feed)", 4f / 5f, "Portrait"),
    RATIO_3_4("3:4 (Classic)", 3f / 4f, "Classic")
}

enum class FilterPreset(val displayName: String, val description: String) {
    NORMAL("Normal", "Original natural colors"),
    CYBERPUNK("Cyberpunk", "Futuristic neon cyan & violet glow"),
    VINTAGE_VHS("Vintage VHS", "Retro analog tape warmth & muted grain"),
    CINEMATIC_GOLD("Cinematic Gold", "Warm Hollywood blockbuster tones"),
    SOFT_PINK("Soft Pink", "Dreamy pastel aesthetic for vlogs"),
    NEO_NOIR("Neo Noir", "High contrast dramatic dark mood"),
    RETRO_80S("Retro 80s", "Vibrant synthwave magenta shift"),
    DRAMA_DARK("Drama Dark", "Moody deep shadows & contrast"),
    WARM_SUMMER("Warm Summer", "Golden hour sunlit contrast"),
    GLITCH_WAVE("Glitch Wave", "Digital distortion & color split"),
    VIVID_POP("Vivid Pop", "Saturated high energy colors"),
    BW_CLASSIC("B&W Classic", "Timeless black and white film")
}

enum class MagicEffect(val displayName: String, val icon: String) {
    NONE("None", "block"),
    NEON_GLOW("Neon Glow", "lightbulb"),
    LIGHT_LEAKS("Light Leaks", "wb_sunny"),
    FILM_GRAIN("Film Grain", "grain"),
    GLITCH_FX("Glitch FX", "flash_on"),
    BOKEH_STARS("Bokeh Stars", "auto_awesome"),
    HEART_PARTICLES("Heart Particles", "favorite"),
    RGB_SPLIT("RGB Split", "layers"),
    ZOOM_BURST("Zoom Burst", "zoom_in")
}

enum class TextAnimStyle(val displayName: String) {
    NONE("Static"),
    FADE_IN("Fade In"),
    SLIDE_UP("Slide Up"),
    TYPEWRITER("Typewriter"),
    BOUNCE("Bounce In")
}

enum class ExportResolution(val label: String, val width: Int, val height: Int) {
    RES_720P("720p HD", 720, 1280),
    RES_1080P("1080p Full HD", 1080, 1920),
    RES_4K("4K Ultra HD", 2160, 3840)
}

enum class ExportFps(val fps: Int) {
    FPS_30(30),
    FPS_60(60)
}

enum class ExportQuality(val label: String, val bitrateMbps: Int) {
    STANDARD("Standard (Fast)", 8),
    HIGH("High Quality (Recommended)", 16),
    ULTRA("Ultra HD (Max Bitrate)", 28)
}

data class TextOverlay(
    val id: String = java.util.UUID.randomUUID().toString(),
    val text: String = "Your Text Here",
    val colorHex: String = "#FFFFFF",
    val bgHex: String = "#80000000",
    val fontSizeSp: Int = 22,
    val animStyle: TextAnimStyle = TextAnimStyle.FADE_IN,
    val startMs: Long = 0,
    val endMs: Long = 10000,
    val xPosRatio: Float = 0.5f,
    val yPosRatio: Float = 0.8f
)

data class StickerOverlay(
    val id: String = java.util.UUID.randomUUID().toString(),
    val emojiOrIcon: String = "🔥",
    val label: String = "Trending",
    val startMs: Long = 0,
    val endMs: Long = 10000,
    val xPosRatio: Float = 0.8f,
    val yPosRatio: Float = 0.2f,
    val scale: Float = 1.0f
)

data class AudioTrack(
    val id: String,
    val title: String,
    val artist: String,
    val category: String,
    val durationSec: Int,
    val bpm: Int = 120
)

data class VideoTemplate(
    val id: String,
    val title: String,
    val category: String,
    val durationMs: Long,
    val filterPreset: FilterPreset,
    val magicEffect: MagicEffect,
    val musicTrack: String,
    val textSample: String,
    val stickerSample: String,
    val aspectRatio: AspectRatio = AspectRatio.RATIO_9_16,
    @DrawableRes val coverDrawableRes: Int? = null
)
