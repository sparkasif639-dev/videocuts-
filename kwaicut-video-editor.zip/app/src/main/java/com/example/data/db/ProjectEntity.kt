package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val title: String,
    val durationMs: Long,
    val aspectRatioName: String,
    val filterPresetName: String,
    val magicEffectName: String,
    val playbackSpeed: Float,
    val brightness: Float,
    val contrast: Float,
    val saturation: Float,
    val warmth: Float,
    val textOverlayText: String,
    val stickerOverlayEmoji: String,
    val audioTrackName: String,
    val isExported: Boolean = false,
    val exportedResolution: String = "1080p",
    val exportedFilePath: String? = null,
    val lastModifiedMs: Long = System.currentTimeMillis(),
    val thumbnailUri: String? = null,
    val videoSourceUri: String? = null
)
