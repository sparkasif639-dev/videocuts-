package com.example.data

import com.example.R

object SampleData {
    val templates = listOf(
        VideoTemplate(
            id = "tpl_cyberpunk",
            title = "Cyberpunk Neon Sync",
            category = "Trending Reels",
            durationMs = 12000,
            filterPreset = FilterPreset.CYBERPUNK,
            magicEffect = MagicEffect.NEON_GLOW,
            musicTrack = "Synthwave Pulse - 128 BPM",
            textSample = "⚡ FUTURE VIBES",
            stickerSample = "🚀",
            aspectRatio = AspectRatio.RATIO_9_16,
            coverDrawableRes = R.drawable.img_template_cyberpunk_1785375972163
        ),
        VideoTemplate(
            id = "tpl_vlog",
            title = "Golden Hour Vlog",
            category = "Travel & Vlog",
            durationMs = 15000,
            filterPreset = FilterPreset.WARM_SUMMER,
            magicEffect = MagicEffect.LIGHT_LEAKS,
            musicTrack = "Acoustic Breeze - Sunset",
            textSample = "Golden Hour Memories ✨",
            stickerSample = "🌅",
            aspectRatio = AspectRatio.RATIO_9_16,
            coverDrawableRes = R.drawable.img_template_vlog_1785375983369
        ),
        VideoTemplate(
            id = "tpl_retro",
            title = "Retro 80s Synth Reel",
            category = "Vintage FX",
            durationMs = 10000,
            filterPreset = FilterPreset.VINTAGE_VHS,
            magicEffect = MagicEffect.FILM_GRAIN,
            musicTrack = "Lo-Fi Midnight Chill",
            textSample = "TAPE 01 • RETRO",
            stickerSample = "📼",
            aspectRatio = AspectRatio.RATIO_9_16,
            coverDrawableRes = R.drawable.img_template_retro_1785375995139
        ),
        VideoTemplate(
            id = "tpl_glitch",
            title = "Glitch Pop Beat Drop",
            category = "Music Sync",
            durationMs = 8000,
            filterPreset = FilterPreset.GLITCH_WAVE,
            magicEffect = MagicEffect.GLITCH_FX,
            musicTrack = "Hyperpop Bass Drop",
            textSample = "BOOM! 🔥",
            stickerSample = "⚡",
            aspectRatio = AspectRatio.RATIO_9_16,
            coverDrawableRes = R.drawable.img_template_cyberpunk_1785375972163
        ),
        VideoTemplate(
            id = "tpl_cinematic",
            title = "Hollywood Cinematic Trailer",
            category = "Cinematic",
            durationMs = 18000,
            filterPreset = FilterPreset.CINEMATIC_GOLD,
            magicEffect = MagicEffect.RGB_SPLIT,
            musicTrack = "Epic Orchestral Rise",
            textSample = "IN A WORLD...",
            stickerSample = "🎬",
            aspectRatio = AspectRatio.RATIO_16_9,
            coverDrawableRes = R.drawable.img_template_vlog_1785375983369
        )
    )

    val audioTracks = listOf(
        AudioTrack("m1", "Synthwave Pulse", "Kwai Studio Beats", "Electronic", 30, 128),
        AudioTrack("m2", "Golden Sunset Chill", "Acoustic Vibe", "Lo-Fi", 45, 85),
        AudioTrack("m3", "Hyperpop Bass Drop", "DJ Cyber", "Trending", 25, 140),
        AudioTrack("m4", "Epic Orchestral Rise", "Film Scoring", "Cinematic", 60, 110),
        AudioTrack("m5", "Vlog Energy Bounce", "Summer Hits", "Pop", 35, 120),
        AudioTrack("m6", "Midnight Coffee Chill", "Relax Beats", "Lo-Fi", 40, 75)
    )
}
